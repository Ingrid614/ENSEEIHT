/**
 */
package contraintes.tests;

import contraintes.ContrainteBoards;
import contraintes.ContraintesFactory;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Contrainte Boards</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class ContrainteBoardsTest extends ContrainteTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(ContrainteBoardsTest.class);
	}

	/**
	 * Constructs a new Contrainte Boards test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContrainteBoardsTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Contrainte Boards test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected ContrainteBoards getFixture() {
		return (ContrainteBoards)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(ContraintesFactory.eINSTANCE.createContrainteBoards());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //ContrainteBoardsTest
