/**
 */
package contraintes.tests;

import contraintes.ContraintesFactory;
import contraintes.ZoneInterdite;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Zone Interdite</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class ZoneInterditeTest extends ContrainteTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(ZoneInterditeTest.class);
	}

	/**
	 * Constructs a new Zone Interdite test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ZoneInterditeTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Zone Interdite test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected ZoneInterdite getFixture() {
		return (ZoneInterdite)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(ContraintesFactory.eINSTANCE.createZoneInterdite());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //ZoneInterditeTest
