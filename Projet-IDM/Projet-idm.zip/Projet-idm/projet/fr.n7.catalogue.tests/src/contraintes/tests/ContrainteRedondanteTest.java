/**
 */
package contraintes.tests;

import contraintes.ContrainteRedondante;
import contraintes.ContraintesFactory;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Contrainte Redondante</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class ContrainteRedondanteTest extends ContrainteTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(ContrainteRedondanteTest.class);
	}

	/**
	 * Constructs a new Contrainte Redondante test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContrainteRedondanteTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Contrainte Redondante test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected ContrainteRedondante getFixture() {
		return (ContrainteRedondante)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(ContraintesFactory.eINSTANCE.createContrainteRedondante());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //ContrainteRedondanteTest
