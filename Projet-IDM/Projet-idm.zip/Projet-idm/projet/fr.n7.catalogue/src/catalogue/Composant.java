/**
 */
package catalogue;

import contraintes.Contrainte;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Composant</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link catalogue.Composant#getId <em>Id</em>}</li>
 *   <li>{@link catalogue.Composant#getFabricant <em>Fabricant</em>}</li>
 *   <li>{@link catalogue.Composant#getEmpreinte <em>Empreinte</em>}</li>
 *   <li>{@link catalogue.Composant#getMetadonnees <em>Metadonnees</em>}</li>
 *   <li>{@link catalogue.Composant#getPorts <em>Ports</em>}</li>
 *   <li>{@link catalogue.Composant#getContraintes <em>Contraintes</em>}</li>
 * </ul>
 *
 * @see catalogue.CataloguePackage#getComposant()
 * @model
 * @generated
 */
public interface Composant extends EObject {
	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #setId(String)
	 * @see catalogue.CataloguePackage#getComposant_Id()
	 * @model required="true"
	 * @generated
	 */
	String getId();

	/**
	 * Sets the value of the '{@link catalogue.Composant#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id</em>' attribute.
	 * @see #getId()
	 * @generated
	 */
	void setId(String value);

	/**
	 * Returns the value of the '<em><b>Fabricant</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fabricant</em>' attribute.
	 * @see #setFabricant(String)
	 * @see catalogue.CataloguePackage#getComposant_Fabricant()
	 * @model required="true"
	 * @generated
	 */
	String getFabricant();

	/**
	 * Sets the value of the '{@link catalogue.Composant#getFabricant <em>Fabricant</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Fabricant</em>' attribute.
	 * @see #getFabricant()
	 * @generated
	 */
	void setFabricant(String value);

	/**
	 * Returns the value of the '<em><b>Empreinte</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Empreinte</em>' reference.
	 * @see #setEmpreinte(Empreinte)
	 * @see catalogue.CataloguePackage#getComposant_Empreinte()
	 * @model required="true"
	 * @generated
	 */
	Empreinte getEmpreinte();

	/**
	 * Sets the value of the '{@link catalogue.Composant#getEmpreinte <em>Empreinte</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Empreinte</em>' reference.
	 * @see #getEmpreinte()
	 * @generated
	 */
	void setEmpreinte(Empreinte value);

	/**
	 * Returns the value of the '<em><b>Metadonnees</b></em>' reference list.
	 * The list contents are of type {@link catalogue.Metadonnee}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Metadonnees</em>' reference list.
	 * @see catalogue.CataloguePackage#getComposant_Metadonnees()
	 * @model
	 * @generated
	 */
	EList<Metadonnee> getMetadonnees();

	/**
	 * Returns the value of the '<em><b>Ports</b></em>' reference list.
	 * The list contents are of type {@link catalogue.Port}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ports</em>' reference list.
	 * @see catalogue.CataloguePackage#getComposant_Ports()
	 * @model required="true"
	 * @generated
	 */
	EList<Port> getPorts();

	/**
	 * Returns the value of the '<em><b>Contraintes</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Contraintes</em>' reference.
	 * @see #setContraintes(Contrainte)
	 * @see catalogue.CataloguePackage#getComposant_Contraintes()
	 * @model
	 * @generated
	 */
	Contrainte getContraintes();

	/**
	 * Sets the value of the '{@link catalogue.Composant#getContraintes <em>Contraintes</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Contraintes</em>' reference.
	 * @see #getContraintes()
	 * @generated
	 */
	void setContraintes(Contrainte value);

} // Composant
