/**
 */
package catalogue;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see catalogue.CatalogueFactory
 * @model kind="package"
 * @generated
 */
public interface CataloguePackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "catalogue";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://catalogue";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "catalogue";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	CataloguePackage eINSTANCE = catalogue.impl.CataloguePackageImpl.init();

	/**
	 * The meta object id for the '{@link catalogue.impl.CatalogueImpl <em>Catalogue</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see catalogue.impl.CatalogueImpl
	 * @see catalogue.impl.CataloguePackageImpl#getCatalogue()
	 * @generated
	 */
	int CATALOGUE = 0;

	/**
	 * The feature id for the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATALOGUE__NOM = 0;

	/**
	 * The feature id for the '<em><b>Composants</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATALOGUE__COMPOSANTS = 1;

	/**
	 * The number of structural features of the '<em>Catalogue</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATALOGUE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Catalogue</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CATALOGUE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link catalogue.impl.ComposantImpl <em>Composant</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see catalogue.impl.ComposantImpl
	 * @see catalogue.impl.CataloguePackageImpl#getComposant()
	 * @generated
	 */
	int COMPOSANT = 1;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT__ID = 0;

	/**
	 * The feature id for the '<em><b>Fabricant</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT__FABRICANT = 1;

	/**
	 * The feature id for the '<em><b>Empreinte</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT__EMPREINTE = 2;

	/**
	 * The feature id for the '<em><b>Metadonnees</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT__METADONNEES = 3;

	/**
	 * The feature id for the '<em><b>Ports</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT__PORTS = 4;

	/**
	 * The feature id for the '<em><b>Contraintes</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT__CONTRAINTES = 5;

	/**
	 * The number of structural features of the '<em>Composant</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Composant</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSANT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link catalogue.impl.MetadonneeImpl <em>Metadonnee</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see catalogue.impl.MetadonneeImpl
	 * @see catalogue.impl.CataloguePackageImpl#getMetadonnee()
	 * @generated
	 */
	int METADONNEE = 2;

	/**
	 * The feature id for the '<em><b>Cle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METADONNEE__CLE = 0;

	/**
	 * The feature id for the '<em><b>Valeur</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METADONNEE__VALEUR = 1;

	/**
	 * The number of structural features of the '<em>Metadonnee</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METADONNEE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Metadonnee</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int METADONNEE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link catalogue.impl.EmpreinteImpl <em>Empreinte</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see catalogue.impl.EmpreinteImpl
	 * @see catalogue.impl.CataloguePackageImpl#getEmpreinte()
	 * @generated
	 */
	int EMPREINTE = 3;

	/**
	 * The feature id for the '<em><b>Longueur</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMPREINTE__LONGUEUR = 0;

	/**
	 * The feature id for the '<em><b>Largeur</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMPREINTE__LARGEUR = 1;

	/**
	 * The feature id for the '<em><b>Forme</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMPREINTE__FORME = 2;

	/**
	 * The feature id for the '<em><b>Ports</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMPREINTE__PORTS = 3;

	/**
	 * The number of structural features of the '<em>Empreinte</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMPREINTE_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Empreinte</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EMPREINTE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link catalogue.impl.PortImpl <em>Port</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see catalogue.impl.PortImpl
	 * @see catalogue.impl.CataloguePackageImpl#getPort()
	 * @generated
	 */
	int PORT = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT__NAME = 0;

	/**
	 * The feature id for the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT__X = 1;

	/**
	 * The feature id for the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT__Y = 2;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT__TYPE = 3;

	/**
	 * The feature id for the '<em><b>Forme</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT__FORME = 4;

	/**
	 * The number of structural features of the '<em>Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Port</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PORT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link catalogue.PortType <em>Port Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see catalogue.PortType
	 * @see catalogue.impl.CataloguePackageImpl#getPortType()
	 * @generated
	 */
	int PORT_TYPE = 5;

	/**
	 * The meta object id for the '{@link catalogue.FormeEmpreinte <em>Forme Empreinte</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see catalogue.FormeEmpreinte
	 * @see catalogue.impl.CataloguePackageImpl#getFormeEmpreinte()
	 * @generated
	 */
	int FORME_EMPREINTE = 6;


	/**
	 * Returns the meta object for class '{@link catalogue.Catalogue <em>Catalogue</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Catalogue</em>'.
	 * @see catalogue.Catalogue
	 * @generated
	 */
	EClass getCatalogue();

	/**
	 * Returns the meta object for the attribute '{@link catalogue.Catalogue#getNom <em>Nom</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Nom</em>'.
	 * @see catalogue.Catalogue#getNom()
	 * @see #getCatalogue()
	 * @generated
	 */
	EAttribute getCatalogue_Nom();

	/**
	 * Returns the meta object for the containment reference list '{@link catalogue.Catalogue#getComposants <em>Composants</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Composants</em>'.
	 * @see catalogue.Catalogue#getComposants()
	 * @see #getCatalogue()
	 * @generated
	 */
	EReference getCatalogue_Composants();

	/**
	 * Returns the meta object for class '{@link catalogue.Composant <em>Composant</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Composant</em>'.
	 * @see catalogue.Composant
	 * @generated
	 */
	EClass getComposant();

	/**
	 * Returns the meta object for the attribute '{@link catalogue.Composant#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see catalogue.Composant#getId()
	 * @see #getComposant()
	 * @generated
	 */
	EAttribute getComposant_Id();

	/**
	 * Returns the meta object for the attribute '{@link catalogue.Composant#getFabricant <em>Fabricant</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Fabricant</em>'.
	 * @see catalogue.Composant#getFabricant()
	 * @see #getComposant()
	 * @generated
	 */
	EAttribute getComposant_Fabricant();

	/**
	 * Returns the meta object for the reference '{@link catalogue.Composant#getEmpreinte <em>Empreinte</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Empreinte</em>'.
	 * @see catalogue.Composant#getEmpreinte()
	 * @see #getComposant()
	 * @generated
	 */
	EReference getComposant_Empreinte();

	/**
	 * Returns the meta object for the reference list '{@link catalogue.Composant#getMetadonnees <em>Metadonnees</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Metadonnees</em>'.
	 * @see catalogue.Composant#getMetadonnees()
	 * @see #getComposant()
	 * @generated
	 */
	EReference getComposant_Metadonnees();

	/**
	 * Returns the meta object for the reference list '{@link catalogue.Composant#getPorts <em>Ports</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Ports</em>'.
	 * @see catalogue.Composant#getPorts()
	 * @see #getComposant()
	 * @generated
	 */
	EReference getComposant_Ports();

	/**
	 * Returns the meta object for the reference '{@link catalogue.Composant#getContraintes <em>Contraintes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Contraintes</em>'.
	 * @see catalogue.Composant#getContraintes()
	 * @see #getComposant()
	 * @generated
	 */
	EReference getComposant_Contraintes();

	/**
	 * Returns the meta object for class '{@link catalogue.Metadonnee <em>Metadonnee</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Metadonnee</em>'.
	 * @see catalogue.Metadonnee
	 * @generated
	 */
	EClass getMetadonnee();

	/**
	 * Returns the meta object for the attribute '{@link catalogue.Metadonnee#getCle <em>Cle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Cle</em>'.
	 * @see catalogue.Metadonnee#getCle()
	 * @see #getMetadonnee()
	 * @generated
	 */
	EAttribute getMetadonnee_Cle();

	/**
	 * Returns the meta object for the attribute '{@link catalogue.Metadonnee#getValeur <em>Valeur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Valeur</em>'.
	 * @see catalogue.Metadonnee#getValeur()
	 * @see #getMetadonnee()
	 * @generated
	 */
	EAttribute getMetadonnee_Valeur();

	/**
	 * Returns the meta object for class '{@link catalogue.Empreinte <em>Empreinte</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Empreinte</em>'.
	 * @see catalogue.Empreinte
	 * @generated
	 */
	EClass getEmpreinte();

	/**
	 * Returns the meta object for the attribute '{@link catalogue.Empreinte#getLongueur <em>Longueur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Longueur</em>'.
	 * @see catalogue.Empreinte#getLongueur()
	 * @see #getEmpreinte()
	 * @generated
	 */
	EAttribute getEmpreinte_Longueur();

	/**
	 * Returns the meta object for the attribute '{@link catalogue.Empreinte#getLargeur <em>Largeur</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Largeur</em>'.
	 * @see catalogue.Empreinte#getLargeur()
	 * @see #getEmpreinte()
	 * @generated
	 */
	EAttribute getEmpreinte_Largeur();

	/**
	 * Returns the meta object for the attribute '{@link catalogue.Empreinte#getForme <em>Forme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Forme</em>'.
	 * @see catalogue.Empreinte#getForme()
	 * @see #getEmpreinte()
	 * @generated
	 */
	EAttribute getEmpreinte_Forme();

	/**
	 * Returns the meta object for the reference list '{@link catalogue.Empreinte#getPorts <em>Ports</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Ports</em>'.
	 * @see catalogue.Empreinte#getPorts()
	 * @see #getEmpreinte()
	 * @generated
	 */
	EReference getEmpreinte_Ports();

	/**
	 * Returns the meta object for class '{@link catalogue.Port <em>Port</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Port</em>'.
	 * @see catalogue.Port
	 * @generated
	 */
	EClass getPort();

	/**
	 * Returns the meta object for the attribute '{@link catalogue.Port#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see catalogue.Port#getName()
	 * @see #getPort()
	 * @generated
	 */
	EAttribute getPort_Name();

	/**
	 * Returns the meta object for the attribute '{@link catalogue.Port#getX <em>X</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>X</em>'.
	 * @see catalogue.Port#getX()
	 * @see #getPort()
	 * @generated
	 */
	EAttribute getPort_X();

	/**
	 * Returns the meta object for the attribute '{@link catalogue.Port#getY <em>Y</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Y</em>'.
	 * @see catalogue.Port#getY()
	 * @see #getPort()
	 * @generated
	 */
	EAttribute getPort_Y();

	/**
	 * Returns the meta object for the attribute '{@link catalogue.Port#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see catalogue.Port#getType()
	 * @see #getPort()
	 * @generated
	 */
	EAttribute getPort_Type();

	/**
	 * Returns the meta object for the attribute '{@link catalogue.Port#getForme <em>Forme</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Forme</em>'.
	 * @see catalogue.Port#getForme()
	 * @see #getPort()
	 * @generated
	 */
	EAttribute getPort_Forme();

	/**
	 * Returns the meta object for enum '{@link catalogue.PortType <em>Port Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Port Type</em>'.
	 * @see catalogue.PortType
	 * @generated
	 */
	EEnum getPortType();

	/**
	 * Returns the meta object for enum '{@link catalogue.FormeEmpreinte <em>Forme Empreinte</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Forme Empreinte</em>'.
	 * @see catalogue.FormeEmpreinte
	 * @generated
	 */
	EEnum getFormeEmpreinte();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	CatalogueFactory getCatalogueFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link catalogue.impl.CatalogueImpl <em>Catalogue</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see catalogue.impl.CatalogueImpl
		 * @see catalogue.impl.CataloguePackageImpl#getCatalogue()
		 * @generated
		 */
		EClass CATALOGUE = eINSTANCE.getCatalogue();

		/**
		 * The meta object literal for the '<em><b>Nom</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CATALOGUE__NOM = eINSTANCE.getCatalogue_Nom();

		/**
		 * The meta object literal for the '<em><b>Composants</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CATALOGUE__COMPOSANTS = eINSTANCE.getCatalogue_Composants();

		/**
		 * The meta object literal for the '{@link catalogue.impl.ComposantImpl <em>Composant</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see catalogue.impl.ComposantImpl
		 * @see catalogue.impl.CataloguePackageImpl#getComposant()
		 * @generated
		 */
		EClass COMPOSANT = eINSTANCE.getComposant();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMPOSANT__ID = eINSTANCE.getComposant_Id();

		/**
		 * The meta object literal for the '<em><b>Fabricant</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COMPOSANT__FABRICANT = eINSTANCE.getComposant_Fabricant();

		/**
		 * The meta object literal for the '<em><b>Empreinte</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPOSANT__EMPREINTE = eINSTANCE.getComposant_Empreinte();

		/**
		 * The meta object literal for the '<em><b>Metadonnees</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPOSANT__METADONNEES = eINSTANCE.getComposant_Metadonnees();

		/**
		 * The meta object literal for the '<em><b>Ports</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPOSANT__PORTS = eINSTANCE.getComposant_Ports();

		/**
		 * The meta object literal for the '<em><b>Contraintes</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPOSANT__CONTRAINTES = eINSTANCE.getComposant_Contraintes();

		/**
		 * The meta object literal for the '{@link catalogue.impl.MetadonneeImpl <em>Metadonnee</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see catalogue.impl.MetadonneeImpl
		 * @see catalogue.impl.CataloguePackageImpl#getMetadonnee()
		 * @generated
		 */
		EClass METADONNEE = eINSTANCE.getMetadonnee();

		/**
		 * The meta object literal for the '<em><b>Cle</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute METADONNEE__CLE = eINSTANCE.getMetadonnee_Cle();

		/**
		 * The meta object literal for the '<em><b>Valeur</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute METADONNEE__VALEUR = eINSTANCE.getMetadonnee_Valeur();

		/**
		 * The meta object literal for the '{@link catalogue.impl.EmpreinteImpl <em>Empreinte</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see catalogue.impl.EmpreinteImpl
		 * @see catalogue.impl.CataloguePackageImpl#getEmpreinte()
		 * @generated
		 */
		EClass EMPREINTE = eINSTANCE.getEmpreinte();

		/**
		 * The meta object literal for the '<em><b>Longueur</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EMPREINTE__LONGUEUR = eINSTANCE.getEmpreinte_Longueur();

		/**
		 * The meta object literal for the '<em><b>Largeur</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EMPREINTE__LARGEUR = eINSTANCE.getEmpreinte_Largeur();

		/**
		 * The meta object literal for the '<em><b>Forme</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EMPREINTE__FORME = eINSTANCE.getEmpreinte_Forme();

		/**
		 * The meta object literal for the '<em><b>Ports</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EMPREINTE__PORTS = eINSTANCE.getEmpreinte_Ports();

		/**
		 * The meta object literal for the '{@link catalogue.impl.PortImpl <em>Port</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see catalogue.impl.PortImpl
		 * @see catalogue.impl.CataloguePackageImpl#getPort()
		 * @generated
		 */
		EClass PORT = eINSTANCE.getPort();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PORT__NAME = eINSTANCE.getPort_Name();

		/**
		 * The meta object literal for the '<em><b>X</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PORT__X = eINSTANCE.getPort_X();

		/**
		 * The meta object literal for the '<em><b>Y</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PORT__Y = eINSTANCE.getPort_Y();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PORT__TYPE = eINSTANCE.getPort_Type();

		/**
		 * The meta object literal for the '<em><b>Forme</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PORT__FORME = eINSTANCE.getPort_Forme();

		/**
		 * The meta object literal for the '{@link catalogue.PortType <em>Port Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see catalogue.PortType
		 * @see catalogue.impl.CataloguePackageImpl#getPortType()
		 * @generated
		 */
		EEnum PORT_TYPE = eINSTANCE.getPortType();

		/**
		 * The meta object literal for the '{@link catalogue.FormeEmpreinte <em>Forme Empreinte</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see catalogue.FormeEmpreinte
		 * @see catalogue.impl.CataloguePackageImpl#getFormeEmpreinte()
		 * @generated
		 */
		EEnum FORME_EMPREINTE = eINSTANCE.getFormeEmpreinte();

	}

} //CataloguePackage
