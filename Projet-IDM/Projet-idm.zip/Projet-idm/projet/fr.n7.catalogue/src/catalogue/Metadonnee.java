/**
 */
package catalogue;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Metadonnee</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link catalogue.Metadonnee#getCle <em>Cle</em>}</li>
 *   <li>{@link catalogue.Metadonnee#getValeur <em>Valeur</em>}</li>
 * </ul>
 *
 * @see catalogue.CataloguePackage#getMetadonnee()
 * @model
 * @generated
 */
public interface Metadonnee extends EObject {
	/**
	 * Returns the value of the '<em><b>Cle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cle</em>' attribute.
	 * @see #setCle(String)
	 * @see catalogue.CataloguePackage#getMetadonnee_Cle()
	 * @model required="true"
	 * @generated
	 */
	String getCle();

	/**
	 * Sets the value of the '{@link catalogue.Metadonnee#getCle <em>Cle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cle</em>' attribute.
	 * @see #getCle()
	 * @generated
	 */
	void setCle(String value);

	/**
	 * Returns the value of the '<em><b>Valeur</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Valeur</em>' attribute.
	 * @see #setValeur(String)
	 * @see catalogue.CataloguePackage#getMetadonnee_Valeur()
	 * @model required="true"
	 * @generated
	 */
	String getValeur();

	/**
	 * Sets the value of the '{@link catalogue.Metadonnee#getValeur <em>Valeur</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Valeur</em>' attribute.
	 * @see #getValeur()
	 * @generated
	 */
	void setValeur(String value);

} // Metadonnee
