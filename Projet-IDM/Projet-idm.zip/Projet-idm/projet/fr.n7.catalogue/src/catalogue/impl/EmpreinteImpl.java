/**
 */
package catalogue.impl;

import catalogue.CataloguePackage;
import catalogue.Empreinte;
import catalogue.FormeEmpreinte;
import catalogue.Port;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Empreinte</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link catalogue.impl.EmpreinteImpl#getLongueur <em>Longueur</em>}</li>
 *   <li>{@link catalogue.impl.EmpreinteImpl#getLargeur <em>Largeur</em>}</li>
 *   <li>{@link catalogue.impl.EmpreinteImpl#getForme <em>Forme</em>}</li>
 *   <li>{@link catalogue.impl.EmpreinteImpl#getPorts <em>Ports</em>}</li>
 * </ul>
 *
 * @generated
 */
public class EmpreinteImpl extends MinimalEObjectImpl.Container implements Empreinte {
	/**
	 * The default value of the '{@link #getLongueur() <em>Longueur</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLongueur()
	 * @generated
	 * @ordered
	 */
	protected static final double LONGUEUR_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getLongueur() <em>Longueur</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLongueur()
	 * @generated
	 * @ordered
	 */
	protected double longueur = LONGUEUR_EDEFAULT;

	/**
	 * The default value of the '{@link #getLargeur() <em>Largeur</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLargeur()
	 * @generated
	 * @ordered
	 */
	protected static final double LARGEUR_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getLargeur() <em>Largeur</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLargeur()
	 * @generated
	 * @ordered
	 */
	protected double largeur = LARGEUR_EDEFAULT;

	/**
	 * The default value of the '{@link #getForme() <em>Forme</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getForme()
	 * @generated
	 * @ordered
	 */
	protected static final FormeEmpreinte FORME_EDEFAULT = FormeEmpreinte.RECTANGLE;

	/**
	 * The cached value of the '{@link #getForme() <em>Forme</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getForme()
	 * @generated
	 * @ordered
	 */
	protected FormeEmpreinte forme = FORME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPorts() <em>Ports</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPorts()
	 * @generated
	 * @ordered
	 */
	protected EList<Port> ports;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EmpreinteImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CataloguePackage.Literals.EMPREINTE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getLongueur() {
		return longueur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLongueur(double newLongueur) {
		double oldLongueur = longueur;
		longueur = newLongueur;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CataloguePackage.EMPREINTE__LONGUEUR, oldLongueur, longueur));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getLargeur() {
		return largeur;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLargeur(double newLargeur) {
		double oldLargeur = largeur;
		largeur = newLargeur;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CataloguePackage.EMPREINTE__LARGEUR, oldLargeur, largeur));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public FormeEmpreinte getForme() {
		return forme;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setForme(FormeEmpreinte newForme) {
		FormeEmpreinte oldForme = forme;
		forme = newForme == null ? FORME_EDEFAULT : newForme;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CataloguePackage.EMPREINTE__FORME, oldForme, forme));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Port> getPorts() {
		if (ports == null) {
			ports = new EObjectResolvingEList<Port>(Port.class, this, CataloguePackage.EMPREINTE__PORTS);
		}
		return ports;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CataloguePackage.EMPREINTE__LONGUEUR:
				return getLongueur();
			case CataloguePackage.EMPREINTE__LARGEUR:
				return getLargeur();
			case CataloguePackage.EMPREINTE__FORME:
				return getForme();
			case CataloguePackage.EMPREINTE__PORTS:
				return getPorts();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CataloguePackage.EMPREINTE__LONGUEUR:
				setLongueur((Double)newValue);
				return;
			case CataloguePackage.EMPREINTE__LARGEUR:
				setLargeur((Double)newValue);
				return;
			case CataloguePackage.EMPREINTE__FORME:
				setForme((FormeEmpreinte)newValue);
				return;
			case CataloguePackage.EMPREINTE__PORTS:
				getPorts().clear();
				getPorts().addAll((Collection<? extends Port>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CataloguePackage.EMPREINTE__LONGUEUR:
				setLongueur(LONGUEUR_EDEFAULT);
				return;
			case CataloguePackage.EMPREINTE__LARGEUR:
				setLargeur(LARGEUR_EDEFAULT);
				return;
			case CataloguePackage.EMPREINTE__FORME:
				setForme(FORME_EDEFAULT);
				return;
			case CataloguePackage.EMPREINTE__PORTS:
				getPorts().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CataloguePackage.EMPREINTE__LONGUEUR:
				return longueur != LONGUEUR_EDEFAULT;
			case CataloguePackage.EMPREINTE__LARGEUR:
				return largeur != LARGEUR_EDEFAULT;
			case CataloguePackage.EMPREINTE__FORME:
				return forme != FORME_EDEFAULT;
			case CataloguePackage.EMPREINTE__PORTS:
				return ports != null && !ports.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (longueur: ");
		result.append(longueur);
		result.append(", largeur: ");
		result.append(largeur);
		result.append(", forme: ");
		result.append(forme);
		result.append(')');
		return result.toString();
	}

} //EmpreinteImpl
