/**
 */
package catalogue.impl;

import catalogue.CataloguePackage;
import catalogue.Composant;
import catalogue.Empreinte;
import catalogue.Metadonnee;
import catalogue.Port;

import contraintes.Contrainte;
import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Composant</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link catalogue.impl.ComposantImpl#getId <em>Id</em>}</li>
 *   <li>{@link catalogue.impl.ComposantImpl#getFabricant <em>Fabricant</em>}</li>
 *   <li>{@link catalogue.impl.ComposantImpl#getEmpreinte <em>Empreinte</em>}</li>
 *   <li>{@link catalogue.impl.ComposantImpl#getMetadonnees <em>Metadonnees</em>}</li>
 *   <li>{@link catalogue.impl.ComposantImpl#getPorts <em>Ports</em>}</li>
 *   <li>{@link catalogue.impl.ComposantImpl#getContraintes <em>Contraintes</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ComposantImpl extends MinimalEObjectImpl.Container implements Composant {
	/**
	 * The default value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected String id = ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getFabricant() <em>Fabricant</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFabricant()
	 * @generated
	 * @ordered
	 */
	protected static final String FABRICANT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFabricant() <em>Fabricant</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFabricant()
	 * @generated
	 * @ordered
	 */
	protected String fabricant = FABRICANT_EDEFAULT;

	/**
	 * The cached value of the '{@link #getEmpreinte() <em>Empreinte</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEmpreinte()
	 * @generated
	 * @ordered
	 */
	protected Empreinte empreinte;

	/**
	 * The cached value of the '{@link #getMetadonnees() <em>Metadonnees</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMetadonnees()
	 * @generated
	 * @ordered
	 */
	protected EList<Metadonnee> metadonnees;

	/**
	 * The cached value of the '{@link #getPorts() <em>Ports</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPorts()
	 * @generated
	 * @ordered
	 */
	protected EList<Port> ports;

	/**
	 * The cached value of the '{@link #getContraintes() <em>Contraintes</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContraintes()
	 * @generated
	 * @ordered
	 */
	protected Contrainte contraintes;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ComposantImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CataloguePackage.Literals.COMPOSANT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getId() {
		return id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setId(String newId) {
		String oldId = id;
		id = newId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CataloguePackage.COMPOSANT__ID, oldId, id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getFabricant() {
		return fabricant;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setFabricant(String newFabricant) {
		String oldFabricant = fabricant;
		fabricant = newFabricant;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CataloguePackage.COMPOSANT__FABRICANT, oldFabricant, fabricant));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Empreinte getEmpreinte() {
		if (empreinte != null && empreinte.eIsProxy()) {
			InternalEObject oldEmpreinte = (InternalEObject)empreinte;
			empreinte = (Empreinte)eResolveProxy(oldEmpreinte);
			if (empreinte != oldEmpreinte) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CataloguePackage.COMPOSANT__EMPREINTE, oldEmpreinte, empreinte));
			}
		}
		return empreinte;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Empreinte basicGetEmpreinte() {
		return empreinte;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setEmpreinte(Empreinte newEmpreinte) {
		Empreinte oldEmpreinte = empreinte;
		empreinte = newEmpreinte;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CataloguePackage.COMPOSANT__EMPREINTE, oldEmpreinte, empreinte));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Metadonnee> getMetadonnees() {
		if (metadonnees == null) {
			metadonnees = new EObjectResolvingEList<Metadonnee>(Metadonnee.class, this, CataloguePackage.COMPOSANT__METADONNEES);
		}
		return metadonnees;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Port> getPorts() {
		if (ports == null) {
			ports = new EObjectResolvingEList<Port>(Port.class, this, CataloguePackage.COMPOSANT__PORTS);
		}
		return ports;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Contrainte getContraintes() {
		if (contraintes != null && contraintes.eIsProxy()) {
			InternalEObject oldContraintes = (InternalEObject)contraintes;
			contraintes = (Contrainte)eResolveProxy(oldContraintes);
			if (contraintes != oldContraintes) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, CataloguePackage.COMPOSANT__CONTRAINTES, oldContraintes, contraintes));
			}
		}
		return contraintes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Contrainte basicGetContraintes() {
		return contraintes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setContraintes(Contrainte newContraintes) {
		Contrainte oldContraintes = contraintes;
		contraintes = newContraintes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CataloguePackage.COMPOSANT__CONTRAINTES, oldContraintes, contraintes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CataloguePackage.COMPOSANT__ID:
				return getId();
			case CataloguePackage.COMPOSANT__FABRICANT:
				return getFabricant();
			case CataloguePackage.COMPOSANT__EMPREINTE:
				if (resolve) return getEmpreinte();
				return basicGetEmpreinte();
			case CataloguePackage.COMPOSANT__METADONNEES:
				return getMetadonnees();
			case CataloguePackage.COMPOSANT__PORTS:
				return getPorts();
			case CataloguePackage.COMPOSANT__CONTRAINTES:
				if (resolve) return getContraintes();
				return basicGetContraintes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CataloguePackage.COMPOSANT__ID:
				setId((String)newValue);
				return;
			case CataloguePackage.COMPOSANT__FABRICANT:
				setFabricant((String)newValue);
				return;
			case CataloguePackage.COMPOSANT__EMPREINTE:
				setEmpreinte((Empreinte)newValue);
				return;
			case CataloguePackage.COMPOSANT__METADONNEES:
				getMetadonnees().clear();
				getMetadonnees().addAll((Collection<? extends Metadonnee>)newValue);
				return;
			case CataloguePackage.COMPOSANT__PORTS:
				getPorts().clear();
				getPorts().addAll((Collection<? extends Port>)newValue);
				return;
			case CataloguePackage.COMPOSANT__CONTRAINTES:
				setContraintes((Contrainte)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case CataloguePackage.COMPOSANT__ID:
				setId(ID_EDEFAULT);
				return;
			case CataloguePackage.COMPOSANT__FABRICANT:
				setFabricant(FABRICANT_EDEFAULT);
				return;
			case CataloguePackage.COMPOSANT__EMPREINTE:
				setEmpreinte((Empreinte)null);
				return;
			case CataloguePackage.COMPOSANT__METADONNEES:
				getMetadonnees().clear();
				return;
			case CataloguePackage.COMPOSANT__PORTS:
				getPorts().clear();
				return;
			case CataloguePackage.COMPOSANT__CONTRAINTES:
				setContraintes((Contrainte)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CataloguePackage.COMPOSANT__ID:
				return ID_EDEFAULT == null ? id != null : !ID_EDEFAULT.equals(id);
			case CataloguePackage.COMPOSANT__FABRICANT:
				return FABRICANT_EDEFAULT == null ? fabricant != null : !FABRICANT_EDEFAULT.equals(fabricant);
			case CataloguePackage.COMPOSANT__EMPREINTE:
				return empreinte != null;
			case CataloguePackage.COMPOSANT__METADONNEES:
				return metadonnees != null && !metadonnees.isEmpty();
			case CataloguePackage.COMPOSANT__PORTS:
				return ports != null && !ports.isEmpty();
			case CataloguePackage.COMPOSANT__CONTRAINTES:
				return contraintes != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (id: ");
		result.append(id);
		result.append(", fabricant: ");
		result.append(fabricant);
		result.append(')');
		return result.toString();
	}

} //ComposantImpl
