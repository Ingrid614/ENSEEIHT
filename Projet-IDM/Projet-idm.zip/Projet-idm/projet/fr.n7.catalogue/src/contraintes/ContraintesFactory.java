/**
 */
package contraintes;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see contraintes.ContraintesPackage
 * @generated
 */
public interface ContraintesFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ContraintesFactory eINSTANCE = contraintes.impl.ContraintesFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>ET</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>ET</em>'.
	 * @generated
	 */
	ET createET();

	/**
	 * Returns a new object of class '<em>Ou</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Ou</em>'.
	 * @generated
	 */
	Ou createOu();

	/**
	 * Returns a new object of class '<em>Non</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Non</em>'.
	 * @generated
	 */
	Non createNon();

	/**
	 * Returns a new object of class '<em>Min Distance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Min Distance</em>'.
	 * @generated
	 */
	MinDistance createMinDistance();

	/**
	 * Returns a new object of class '<em>Zone Interdite</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Zone Interdite</em>'.
	 * @generated
	 */
	ZoneInterdite createZoneInterdite();

	/**
	 * Returns a new object of class '<em>Contrainte Redondante</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Contrainte Redondante</em>'.
	 * @generated
	 */
	ContrainteRedondante createContrainteRedondante();

	/**
	 * Returns a new object of class '<em>Contrainte Boards</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Contrainte Boards</em>'.
	 * @generated
	 */
	ContrainteBoards createContrainteBoards();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	ContraintesPackage getContraintesPackage();

} //ContraintesFactory
