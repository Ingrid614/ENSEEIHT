/**
 */
package contraintes.impl;

import contraintes.ContrainteBoards;
import contraintes.ContraintesPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Contrainte Boards</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link contraintes.impl.ContrainteBoardsImpl#getCoucheRequise <em>Couche Requise</em>}</li>
 *   <li>{@link contraintes.impl.ContrainteBoardsImpl#isCoucheExterneInterdite <em>Couche Externe Interdite</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ContrainteBoardsImpl extends ContrainteImpl implements ContrainteBoards {
	/**
	 * The default value of the '{@link #getCoucheRequise() <em>Couche Requise</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCoucheRequise()
	 * @generated
	 * @ordered
	 */
	protected static final String COUCHE_REQUISE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCoucheRequise() <em>Couche Requise</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCoucheRequise()
	 * @generated
	 * @ordered
	 */
	protected String coucheRequise = COUCHE_REQUISE_EDEFAULT;

	/**
	 * The default value of the '{@link #isCoucheExterneInterdite() <em>Couche Externe Interdite</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isCoucheExterneInterdite()
	 * @generated
	 * @ordered
	 */
	protected static final boolean COUCHE_EXTERNE_INTERDITE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isCoucheExterneInterdite() <em>Couche Externe Interdite</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isCoucheExterneInterdite()
	 * @generated
	 * @ordered
	 */
	protected boolean coucheExterneInterdite = COUCHE_EXTERNE_INTERDITE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ContrainteBoardsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ContraintesPackage.Literals.CONTRAINTE_BOARDS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getCoucheRequise() {
		return coucheRequise;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCoucheRequise(String newCoucheRequise) {
		String oldCoucheRequise = coucheRequise;
		coucheRequise = newCoucheRequise;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ContraintesPackage.CONTRAINTE_BOARDS__COUCHE_REQUISE, oldCoucheRequise, coucheRequise));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isCoucheExterneInterdite() {
		return coucheExterneInterdite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCoucheExterneInterdite(boolean newCoucheExterneInterdite) {
		boolean oldCoucheExterneInterdite = coucheExterneInterdite;
		coucheExterneInterdite = newCoucheExterneInterdite;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ContraintesPackage.CONTRAINTE_BOARDS__COUCHE_EXTERNE_INTERDITE, oldCoucheExterneInterdite, coucheExterneInterdite));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ContraintesPackage.CONTRAINTE_BOARDS__COUCHE_REQUISE:
				return getCoucheRequise();
			case ContraintesPackage.CONTRAINTE_BOARDS__COUCHE_EXTERNE_INTERDITE:
				return isCoucheExterneInterdite();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ContraintesPackage.CONTRAINTE_BOARDS__COUCHE_REQUISE:
				setCoucheRequise((String)newValue);
				return;
			case ContraintesPackage.CONTRAINTE_BOARDS__COUCHE_EXTERNE_INTERDITE:
				setCoucheExterneInterdite((Boolean)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ContraintesPackage.CONTRAINTE_BOARDS__COUCHE_REQUISE:
				setCoucheRequise(COUCHE_REQUISE_EDEFAULT);
				return;
			case ContraintesPackage.CONTRAINTE_BOARDS__COUCHE_EXTERNE_INTERDITE:
				setCoucheExterneInterdite(COUCHE_EXTERNE_INTERDITE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ContraintesPackage.CONTRAINTE_BOARDS__COUCHE_REQUISE:
				return COUCHE_REQUISE_EDEFAULT == null ? coucheRequise != null : !COUCHE_REQUISE_EDEFAULT.equals(coucheRequise);
			case ContraintesPackage.CONTRAINTE_BOARDS__COUCHE_EXTERNE_INTERDITE:
				return coucheExterneInterdite != COUCHE_EXTERNE_INTERDITE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (coucheRequise: ");
		result.append(coucheRequise);
		result.append(", coucheExterneInterdite: ");
		result.append(coucheExterneInterdite);
		result.append(')');
		return result.toString();
	}

} //ContrainteBoardsImpl
