/**
 */
package contraintes.impl;

import contraintes.Contrainte;
import contraintes.ContraintesPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Contrainte</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class ContrainteImpl extends MinimalEObjectImpl.Container implements Contrainte {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ContrainteImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ContraintesPackage.Literals.CONTRAINTE;
	}

} //ContrainteImpl
