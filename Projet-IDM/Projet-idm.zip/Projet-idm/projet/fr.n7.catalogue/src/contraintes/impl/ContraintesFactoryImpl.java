/**
 */
package contraintes.impl;

import contraintes.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ContraintesFactoryImpl extends EFactoryImpl implements ContraintesFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ContraintesFactory init() {
		try {
			ContraintesFactory theContraintesFactory = (ContraintesFactory)EPackage.Registry.INSTANCE.getEFactory(ContraintesPackage.eNS_URI);
			if (theContraintesFactory != null) {
				return theContraintesFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ContraintesFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContraintesFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case ContraintesPackage.ET: return createET();
			case ContraintesPackage.OU: return createOu();
			case ContraintesPackage.NON: return createNon();
			case ContraintesPackage.MIN_DISTANCE: return createMinDistance();
			case ContraintesPackage.ZONE_INTERDITE: return createZoneInterdite();
			case ContraintesPackage.CONTRAINTE_REDONDANTE: return createContrainteRedondante();
			case ContraintesPackage.CONTRAINTE_BOARDS: return createContrainteBoards();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ET createET() {
		ETImpl et = new ETImpl();
		return et;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Ou createOu() {
		OuImpl ou = new OuImpl();
		return ou;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Non createNon() {
		NonImpl non = new NonImpl();
		return non;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MinDistance createMinDistance() {
		MinDistanceImpl minDistance = new MinDistanceImpl();
		return minDistance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ZoneInterdite createZoneInterdite() {
		ZoneInterditeImpl zoneInterdite = new ZoneInterditeImpl();
		return zoneInterdite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ContrainteRedondante createContrainteRedondante() {
		ContrainteRedondanteImpl contrainteRedondante = new ContrainteRedondanteImpl();
		return contrainteRedondante;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ContrainteBoards createContrainteBoards() {
		ContrainteBoardsImpl contrainteBoards = new ContrainteBoardsImpl();
		return contrainteBoards;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ContraintesPackage getContraintesPackage() {
		return (ContraintesPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static ContraintesPackage getPackage() {
		return ContraintesPackage.eINSTANCE;
	}

} //ContraintesFactoryImpl
