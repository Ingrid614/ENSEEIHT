/**
 */
package contraintes.impl;

import contraintes.ContraintesPackage;
import contraintes.MinDistance;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Min Distance</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link contraintes.impl.MinDistanceImpl#getMinDistance <em>Min Distance</em>}</li>
 *   <li>{@link contraintes.impl.MinDistanceImpl#getMetadonneeCle <em>Metadonnee Cle</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MinDistanceImpl extends ContrainteImpl implements MinDistance {
	/**
	 * The default value of the '{@link #getMinDistance() <em>Min Distance</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMinDistance()
	 * @generated
	 * @ordered
	 */
	protected static final String MIN_DISTANCE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getMinDistance() <em>Min Distance</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMinDistance()
	 * @generated
	 * @ordered
	 */
	protected String minDistance = MIN_DISTANCE_EDEFAULT;

	/**
	 * The default value of the '{@link #getMetadonneeCle() <em>Metadonnee Cle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMetadonneeCle()
	 * @generated
	 * @ordered
	 */
	protected static final String METADONNEE_CLE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getMetadonneeCle() <em>Metadonnee Cle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMetadonneeCle()
	 * @generated
	 * @ordered
	 */
	protected String metadonneeCle = METADONNEE_CLE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MinDistanceImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ContraintesPackage.Literals.MIN_DISTANCE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getMinDistance() {
		return minDistance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setMinDistance(String newMinDistance) {
		String oldMinDistance = minDistance;
		minDistance = newMinDistance;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ContraintesPackage.MIN_DISTANCE__MIN_DISTANCE, oldMinDistance, minDistance));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getMetadonneeCle() {
		return metadonneeCle;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setMetadonneeCle(String newMetadonneeCle) {
		String oldMetadonneeCle = metadonneeCle;
		metadonneeCle = newMetadonneeCle;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ContraintesPackage.MIN_DISTANCE__METADONNEE_CLE, oldMetadonneeCle, metadonneeCle));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ContraintesPackage.MIN_DISTANCE__MIN_DISTANCE:
				return getMinDistance();
			case ContraintesPackage.MIN_DISTANCE__METADONNEE_CLE:
				return getMetadonneeCle();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ContraintesPackage.MIN_DISTANCE__MIN_DISTANCE:
				setMinDistance((String)newValue);
				return;
			case ContraintesPackage.MIN_DISTANCE__METADONNEE_CLE:
				setMetadonneeCle((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ContraintesPackage.MIN_DISTANCE__MIN_DISTANCE:
				setMinDistance(MIN_DISTANCE_EDEFAULT);
				return;
			case ContraintesPackage.MIN_DISTANCE__METADONNEE_CLE:
				setMetadonneeCle(METADONNEE_CLE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ContraintesPackage.MIN_DISTANCE__MIN_DISTANCE:
				return MIN_DISTANCE_EDEFAULT == null ? minDistance != null : !MIN_DISTANCE_EDEFAULT.equals(minDistance);
			case ContraintesPackage.MIN_DISTANCE__METADONNEE_CLE:
				return METADONNEE_CLE_EDEFAULT == null ? metadonneeCle != null : !METADONNEE_CLE_EDEFAULT.equals(metadonneeCle);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (minDistance: ");
		result.append(minDistance);
		result.append(", metadonneeCle: ");
		result.append(metadonneeCle);
		result.append(')');
		return result.toString();
	}

} //MinDistanceImpl
