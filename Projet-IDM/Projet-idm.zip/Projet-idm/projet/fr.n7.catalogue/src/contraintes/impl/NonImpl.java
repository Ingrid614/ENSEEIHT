/**
 */
package contraintes.impl;

import contraintes.Contrainte;
import contraintes.ContraintesPackage;
import contraintes.Non;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Non</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link contraintes.impl.NonImpl#getOperande <em>Operande</em>}</li>
 * </ul>
 *
 * @generated
 */
public class NonImpl extends ContrainteImpl implements Non {
	/**
	 * The cached value of the '{@link #getOperande() <em>Operande</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOperande()
	 * @generated
	 * @ordered
	 */
	protected Contrainte operande;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NonImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ContraintesPackage.Literals.NON;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Contrainte getOperande() {
		if (operande != null && operande.eIsProxy()) {
			InternalEObject oldOperande = (InternalEObject)operande;
			operande = (Contrainte)eResolveProxy(oldOperande);
			if (operande != oldOperande) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ContraintesPackage.NON__OPERANDE, oldOperande, operande));
			}
		}
		return operande;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Contrainte basicGetOperande() {
		return operande;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setOperande(Contrainte newOperande) {
		Contrainte oldOperande = operande;
		operande = newOperande;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ContraintesPackage.NON__OPERANDE, oldOperande, operande));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ContraintesPackage.NON__OPERANDE:
				if (resolve) return getOperande();
				return basicGetOperande();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ContraintesPackage.NON__OPERANDE:
				setOperande((Contrainte)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ContraintesPackage.NON__OPERANDE:
				setOperande((Contrainte)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ContraintesPackage.NON__OPERANDE:
				return operande != null;
		}
		return super.eIsSet(featureID);
	}

} //NonImpl
