/**
 */
package contraintes.impl;

import contraintes.Contrainte;
import contraintes.ContraintesPackage;
import contraintes.Ou;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Ou</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link contraintes.impl.OuImpl#getGauche <em>Gauche</em>}</li>
 *   <li>{@link contraintes.impl.OuImpl#getDroite <em>Droite</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OuImpl extends ContrainteImpl implements Ou {
	/**
	 * The cached value of the '{@link #getGauche() <em>Gauche</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGauche()
	 * @generated
	 * @ordered
	 */
	protected Contrainte gauche;

	/**
	 * The cached value of the '{@link #getDroite() <em>Droite</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDroite()
	 * @generated
	 * @ordered
	 */
	protected Contrainte droite;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OuImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ContraintesPackage.Literals.OU;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Contrainte getGauche() {
		if (gauche != null && gauche.eIsProxy()) {
			InternalEObject oldGauche = (InternalEObject)gauche;
			gauche = (Contrainte)eResolveProxy(oldGauche);
			if (gauche != oldGauche) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ContraintesPackage.OU__GAUCHE, oldGauche, gauche));
			}
		}
		return gauche;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Contrainte basicGetGauche() {
		return gauche;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setGauche(Contrainte newGauche) {
		Contrainte oldGauche = gauche;
		gauche = newGauche;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ContraintesPackage.OU__GAUCHE, oldGauche, gauche));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Contrainte getDroite() {
		if (droite != null && droite.eIsProxy()) {
			InternalEObject oldDroite = (InternalEObject)droite;
			droite = (Contrainte)eResolveProxy(oldDroite);
			if (droite != oldDroite) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ContraintesPackage.OU__DROITE, oldDroite, droite));
			}
		}
		return droite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Contrainte basicGetDroite() {
		return droite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDroite(Contrainte newDroite) {
		Contrainte oldDroite = droite;
		droite = newDroite;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ContraintesPackage.OU__DROITE, oldDroite, droite));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ContraintesPackage.OU__GAUCHE:
				if (resolve) return getGauche();
				return basicGetGauche();
			case ContraintesPackage.OU__DROITE:
				if (resolve) return getDroite();
				return basicGetDroite();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ContraintesPackage.OU__GAUCHE:
				setGauche((Contrainte)newValue);
				return;
			case ContraintesPackage.OU__DROITE:
				setDroite((Contrainte)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ContraintesPackage.OU__GAUCHE:
				setGauche((Contrainte)null);
				return;
			case ContraintesPackage.OU__DROITE:
				setDroite((Contrainte)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ContraintesPackage.OU__GAUCHE:
				return gauche != null;
			case ContraintesPackage.OU__DROITE:
				return droite != null;
		}
		return super.eIsSet(featureID);
	}

} //OuImpl
