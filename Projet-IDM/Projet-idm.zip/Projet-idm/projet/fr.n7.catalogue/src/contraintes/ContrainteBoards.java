/**
 */
package contraintes;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Contrainte Boards</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link contraintes.ContrainteBoards#getCoucheRequise <em>Couche Requise</em>}</li>
 *   <li>{@link contraintes.ContrainteBoards#isCoucheExterneInterdite <em>Couche Externe Interdite</em>}</li>
 * </ul>
 *
 * @see contraintes.ContraintesPackage#getContrainteBoards()
 * @model
 * @generated
 */
public interface ContrainteBoards extends Contrainte {
	/**
	 * Returns the value of the '<em><b>Couche Requise</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Couche Requise</em>' attribute.
	 * @see #setCoucheRequise(String)
	 * @see contraintes.ContraintesPackage#getContrainteBoards_CoucheRequise()
	 * @model required="true"
	 * @generated
	 */
	String getCoucheRequise();

	/**
	 * Sets the value of the '{@link contraintes.ContrainteBoards#getCoucheRequise <em>Couche Requise</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Couche Requise</em>' attribute.
	 * @see #getCoucheRequise()
	 * @generated
	 */
	void setCoucheRequise(String value);

	/**
	 * Returns the value of the '<em><b>Couche Externe Interdite</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Couche Externe Interdite</em>' attribute.
	 * @see #setCoucheExterneInterdite(boolean)
	 * @see contraintes.ContraintesPackage#getContrainteBoards_CoucheExterneInterdite()
	 * @model required="true"
	 * @generated
	 */
	boolean isCoucheExterneInterdite();

	/**
	 * Sets the value of the '{@link contraintes.ContrainteBoards#isCoucheExterneInterdite <em>Couche Externe Interdite</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Couche Externe Interdite</em>' attribute.
	 * @see #isCoucheExterneInterdite()
	 * @generated
	 */
	void setCoucheExterneInterdite(boolean value);

} // ContrainteBoards
