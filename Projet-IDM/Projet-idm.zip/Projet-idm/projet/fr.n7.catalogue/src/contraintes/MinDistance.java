/**
 */
package contraintes;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Min Distance</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link contraintes.MinDistance#getMinDistance <em>Min Distance</em>}</li>
 *   <li>{@link contraintes.MinDistance#getMetadonneeCle <em>Metadonnee Cle</em>}</li>
 * </ul>
 *
 * @see contraintes.ContraintesPackage#getMinDistance()
 * @model
 * @generated
 */
public interface MinDistance extends Contrainte {
	/**
	 * Returns the value of the '<em><b>Min Distance</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Min Distance</em>' attribute.
	 * @see #setMinDistance(String)
	 * @see contraintes.ContraintesPackage#getMinDistance_MinDistance()
	 * @model required="true"
	 * @generated
	 */
	String getMinDistance();

	/**
	 * Sets the value of the '{@link contraintes.MinDistance#getMinDistance <em>Min Distance</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Min Distance</em>' attribute.
	 * @see #getMinDistance()
	 * @generated
	 */
	void setMinDistance(String value);

	/**
	 * Returns the value of the '<em><b>Metadonnee Cle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Metadonnee Cle</em>' attribute.
	 * @see #setMetadonneeCle(String)
	 * @see contraintes.ContraintesPackage#getMinDistance_MetadonneeCle()
	 * @model required="true"
	 * @generated
	 */
	String getMetadonneeCle();

	/**
	 * Sets the value of the '{@link contraintes.MinDistance#getMetadonneeCle <em>Metadonnee Cle</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Metadonnee Cle</em>' attribute.
	 * @see #getMetadonneeCle()
	 * @generated
	 */
	void setMetadonneeCle(String value);

} // MinDistance
