/**
 */
package contraintes;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Contrainte</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see contraintes.ContraintesPackage#getContrainte()
 * @model abstract="true"
 * @generated
 */
public interface Contrainte extends EObject {
} // Contrainte
