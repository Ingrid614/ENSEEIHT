/**
 */
package contraintes;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>ET</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link contraintes.ET#getGauche <em>Gauche</em>}</li>
 *   <li>{@link contraintes.ET#getDroite <em>Droite</em>}</li>
 * </ul>
 *
 * @see contraintes.ContraintesPackage#getET()
 * @model
 * @generated
 */
public interface ET extends Contrainte {
	/**
	 * Returns the value of the '<em><b>Gauche</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Gauche</em>' reference.
	 * @see #setGauche(Contrainte)
	 * @see contraintes.ContraintesPackage#getET_Gauche()
	 * @model required="true"
	 * @generated
	 */
	Contrainte getGauche();

	/**
	 * Sets the value of the '{@link contraintes.ET#getGauche <em>Gauche</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Gauche</em>' reference.
	 * @see #getGauche()
	 * @generated
	 */
	void setGauche(Contrainte value);

	/**
	 * Returns the value of the '<em><b>Droite</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Droite</em>' reference.
	 * @see #setDroite(Contrainte)
	 * @see contraintes.ContraintesPackage#getET_Droite()
	 * @model required="true"
	 * @generated
	 */
	Contrainte getDroite();

	/**
	 * Sets the value of the '{@link contraintes.ET#getDroite <em>Droite</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Droite</em>' reference.
	 * @see #getDroite()
	 * @generated
	 */
	void setDroite(Contrainte value);

} // ET
