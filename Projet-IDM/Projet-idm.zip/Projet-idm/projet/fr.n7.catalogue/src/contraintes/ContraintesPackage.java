/**
 */
package contraintes;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see contraintes.ContraintesFactory
 * @model kind="package"
 * @generated
 */
public interface ContraintesPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "contraintes";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://contraintes";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "contraintes";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ContraintesPackage eINSTANCE = contraintes.impl.ContraintesPackageImpl.init();

	/**
	 * The meta object id for the '{@link contraintes.impl.ContrainteImpl <em>Contrainte</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see contraintes.impl.ContrainteImpl
	 * @see contraintes.impl.ContraintesPackageImpl#getContrainte()
	 * @generated
	 */
	int CONTRAINTE = 0;

	/**
	 * The number of structural features of the '<em>Contrainte</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTRAINTE_FEATURE_COUNT = 0;

	/**
	 * The number of operations of the '<em>Contrainte</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTRAINTE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link contraintes.impl.ETImpl <em>ET</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see contraintes.impl.ETImpl
	 * @see contraintes.impl.ContraintesPackageImpl#getET()
	 * @generated
	 */
	int ET = 1;

	/**
	 * The feature id for the '<em><b>Gauche</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ET__GAUCHE = CONTRAINTE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Droite</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ET__DROITE = CONTRAINTE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>ET</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ET_FEATURE_COUNT = CONTRAINTE_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>ET</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ET_OPERATION_COUNT = CONTRAINTE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link contraintes.impl.OuImpl <em>Ou</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see contraintes.impl.OuImpl
	 * @see contraintes.impl.ContraintesPackageImpl#getOu()
	 * @generated
	 */
	int OU = 2;

	/**
	 * The feature id for the '<em><b>Gauche</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OU__GAUCHE = CONTRAINTE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Droite</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OU__DROITE = CONTRAINTE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Ou</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OU_FEATURE_COUNT = CONTRAINTE_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Ou</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OU_OPERATION_COUNT = CONTRAINTE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link contraintes.impl.NonImpl <em>Non</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see contraintes.impl.NonImpl
	 * @see contraintes.impl.ContraintesPackageImpl#getNon()
	 * @generated
	 */
	int NON = 3;

	/**
	 * The feature id for the '<em><b>Operande</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NON__OPERANDE = CONTRAINTE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Non</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NON_FEATURE_COUNT = CONTRAINTE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Non</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NON_OPERATION_COUNT = CONTRAINTE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link contraintes.impl.MinDistanceImpl <em>Min Distance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see contraintes.impl.MinDistanceImpl
	 * @see contraintes.impl.ContraintesPackageImpl#getMinDistance()
	 * @generated
	 */
	int MIN_DISTANCE = 4;

	/**
	 * The feature id for the '<em><b>Min Distance</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MIN_DISTANCE__MIN_DISTANCE = CONTRAINTE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Metadonnee Cle</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MIN_DISTANCE__METADONNEE_CLE = CONTRAINTE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Min Distance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MIN_DISTANCE_FEATURE_COUNT = CONTRAINTE_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Min Distance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MIN_DISTANCE_OPERATION_COUNT = CONTRAINTE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link contraintes.impl.ZoneInterditeImpl <em>Zone Interdite</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see contraintes.impl.ZoneInterditeImpl
	 * @see contraintes.impl.ContraintesPackageImpl#getZoneInterdite()
	 * @generated
	 */
	int ZONE_INTERDITE = 5;

	/**
	 * The feature id for the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZONE_INTERDITE__X = CONTRAINTE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZONE_INTERDITE__Y = CONTRAINTE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZONE_INTERDITE__WIDTH = CONTRAINTE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZONE_INTERDITE__HEIGHT = CONTRAINTE_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Zone Interdite</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZONE_INTERDITE_FEATURE_COUNT = CONTRAINTE_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Zone Interdite</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZONE_INTERDITE_OPERATION_COUNT = CONTRAINTE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link contraintes.impl.ContrainteRedondanteImpl <em>Contrainte Redondante</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see contraintes.impl.ContrainteRedondanteImpl
	 * @see contraintes.impl.ContraintesPackageImpl#getContrainteRedondante()
	 * @generated
	 */
	int CONTRAINTE_REDONDANTE = 6;

	/**
	 * The feature id for the '<em><b>Count</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTRAINTE_REDONDANTE__COUNT = CONTRAINTE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Contrainte Redondante</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTRAINTE_REDONDANTE_FEATURE_COUNT = CONTRAINTE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Contrainte Redondante</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTRAINTE_REDONDANTE_OPERATION_COUNT = CONTRAINTE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link contraintes.impl.ContrainteBoardsImpl <em>Contrainte Boards</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see contraintes.impl.ContrainteBoardsImpl
	 * @see contraintes.impl.ContraintesPackageImpl#getContrainteBoards()
	 * @generated
	 */
	int CONTRAINTE_BOARDS = 7;

	/**
	 * The feature id for the '<em><b>Couche Requise</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTRAINTE_BOARDS__COUCHE_REQUISE = CONTRAINTE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Couche Externe Interdite</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTRAINTE_BOARDS__COUCHE_EXTERNE_INTERDITE = CONTRAINTE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Contrainte Boards</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTRAINTE_BOARDS_FEATURE_COUNT = CONTRAINTE_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Contrainte Boards</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTRAINTE_BOARDS_OPERATION_COUNT = CONTRAINTE_OPERATION_COUNT + 0;


	/**
	 * Returns the meta object for class '{@link contraintes.Contrainte <em>Contrainte</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Contrainte</em>'.
	 * @see contraintes.Contrainte
	 * @generated
	 */
	EClass getContrainte();

	/**
	 * Returns the meta object for class '{@link contraintes.ET <em>ET</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>ET</em>'.
	 * @see contraintes.ET
	 * @generated
	 */
	EClass getET();

	/**
	 * Returns the meta object for the reference '{@link contraintes.ET#getGauche <em>Gauche</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Gauche</em>'.
	 * @see contraintes.ET#getGauche()
	 * @see #getET()
	 * @generated
	 */
	EReference getET_Gauche();

	/**
	 * Returns the meta object for the reference '{@link contraintes.ET#getDroite <em>Droite</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Droite</em>'.
	 * @see contraintes.ET#getDroite()
	 * @see #getET()
	 * @generated
	 */
	EReference getET_Droite();

	/**
	 * Returns the meta object for class '{@link contraintes.Ou <em>Ou</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Ou</em>'.
	 * @see contraintes.Ou
	 * @generated
	 */
	EClass getOu();

	/**
	 * Returns the meta object for the reference '{@link contraintes.Ou#getGauche <em>Gauche</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Gauche</em>'.
	 * @see contraintes.Ou#getGauche()
	 * @see #getOu()
	 * @generated
	 */
	EReference getOu_Gauche();

	/**
	 * Returns the meta object for the reference '{@link contraintes.Ou#getDroite <em>Droite</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Droite</em>'.
	 * @see contraintes.Ou#getDroite()
	 * @see #getOu()
	 * @generated
	 */
	EReference getOu_Droite();

	/**
	 * Returns the meta object for class '{@link contraintes.Non <em>Non</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Non</em>'.
	 * @see contraintes.Non
	 * @generated
	 */
	EClass getNon();

	/**
	 * Returns the meta object for the reference '{@link contraintes.Non#getOperande <em>Operande</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Operande</em>'.
	 * @see contraintes.Non#getOperande()
	 * @see #getNon()
	 * @generated
	 */
	EReference getNon_Operande();

	/**
	 * Returns the meta object for class '{@link contraintes.MinDistance <em>Min Distance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Min Distance</em>'.
	 * @see contraintes.MinDistance
	 * @generated
	 */
	EClass getMinDistance();

	/**
	 * Returns the meta object for the attribute '{@link contraintes.MinDistance#getMinDistance <em>Min Distance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Min Distance</em>'.
	 * @see contraintes.MinDistance#getMinDistance()
	 * @see #getMinDistance()
	 * @generated
	 */
	EAttribute getMinDistance_MinDistance();

	/**
	 * Returns the meta object for the attribute '{@link contraintes.MinDistance#getMetadonneeCle <em>Metadonnee Cle</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Metadonnee Cle</em>'.
	 * @see contraintes.MinDistance#getMetadonneeCle()
	 * @see #getMinDistance()
	 * @generated
	 */
	EAttribute getMinDistance_MetadonneeCle();

	/**
	 * Returns the meta object for class '{@link contraintes.ZoneInterdite <em>Zone Interdite</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Zone Interdite</em>'.
	 * @see contraintes.ZoneInterdite
	 * @generated
	 */
	EClass getZoneInterdite();

	/**
	 * Returns the meta object for the attribute '{@link contraintes.ZoneInterdite#getX <em>X</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>X</em>'.
	 * @see contraintes.ZoneInterdite#getX()
	 * @see #getZoneInterdite()
	 * @generated
	 */
	EAttribute getZoneInterdite_X();

	/**
	 * Returns the meta object for the attribute '{@link contraintes.ZoneInterdite#getY <em>Y</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Y</em>'.
	 * @see contraintes.ZoneInterdite#getY()
	 * @see #getZoneInterdite()
	 * @generated
	 */
	EAttribute getZoneInterdite_Y();

	/**
	 * Returns the meta object for the attribute '{@link contraintes.ZoneInterdite#getWidth <em>Width</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Width</em>'.
	 * @see contraintes.ZoneInterdite#getWidth()
	 * @see #getZoneInterdite()
	 * @generated
	 */
	EAttribute getZoneInterdite_Width();

	/**
	 * Returns the meta object for the attribute '{@link contraintes.ZoneInterdite#getHeight <em>Height</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Height</em>'.
	 * @see contraintes.ZoneInterdite#getHeight()
	 * @see #getZoneInterdite()
	 * @generated
	 */
	EAttribute getZoneInterdite_Height();

	/**
	 * Returns the meta object for class '{@link contraintes.ContrainteRedondante <em>Contrainte Redondante</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Contrainte Redondante</em>'.
	 * @see contraintes.ContrainteRedondante
	 * @generated
	 */
	EClass getContrainteRedondante();

	/**
	 * Returns the meta object for the attribute '{@link contraintes.ContrainteRedondante#getCount <em>Count</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Count</em>'.
	 * @see contraintes.ContrainteRedondante#getCount()
	 * @see #getContrainteRedondante()
	 * @generated
	 */
	EAttribute getContrainteRedondante_Count();

	/**
	 * Returns the meta object for class '{@link contraintes.ContrainteBoards <em>Contrainte Boards</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Contrainte Boards</em>'.
	 * @see contraintes.ContrainteBoards
	 * @generated
	 */
	EClass getContrainteBoards();

	/**
	 * Returns the meta object for the attribute '{@link contraintes.ContrainteBoards#getCoucheRequise <em>Couche Requise</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Couche Requise</em>'.
	 * @see contraintes.ContrainteBoards#getCoucheRequise()
	 * @see #getContrainteBoards()
	 * @generated
	 */
	EAttribute getContrainteBoards_CoucheRequise();

	/**
	 * Returns the meta object for the attribute '{@link contraintes.ContrainteBoards#isCoucheExterneInterdite <em>Couche Externe Interdite</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Couche Externe Interdite</em>'.
	 * @see contraintes.ContrainteBoards#isCoucheExterneInterdite()
	 * @see #getContrainteBoards()
	 * @generated
	 */
	EAttribute getContrainteBoards_CoucheExterneInterdite();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ContraintesFactory getContraintesFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link contraintes.impl.ContrainteImpl <em>Contrainte</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see contraintes.impl.ContrainteImpl
		 * @see contraintes.impl.ContraintesPackageImpl#getContrainte()
		 * @generated
		 */
		EClass CONTRAINTE = eINSTANCE.getContrainte();

		/**
		 * The meta object literal for the '{@link contraintes.impl.ETImpl <em>ET</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see contraintes.impl.ETImpl
		 * @see contraintes.impl.ContraintesPackageImpl#getET()
		 * @generated
		 */
		EClass ET = eINSTANCE.getET();

		/**
		 * The meta object literal for the '<em><b>Gauche</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ET__GAUCHE = eINSTANCE.getET_Gauche();

		/**
		 * The meta object literal for the '<em><b>Droite</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ET__DROITE = eINSTANCE.getET_Droite();

		/**
		 * The meta object literal for the '{@link contraintes.impl.OuImpl <em>Ou</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see contraintes.impl.OuImpl
		 * @see contraintes.impl.ContraintesPackageImpl#getOu()
		 * @generated
		 */
		EClass OU = eINSTANCE.getOu();

		/**
		 * The meta object literal for the '<em><b>Gauche</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OU__GAUCHE = eINSTANCE.getOu_Gauche();

		/**
		 * The meta object literal for the '<em><b>Droite</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OU__DROITE = eINSTANCE.getOu_Droite();

		/**
		 * The meta object literal for the '{@link contraintes.impl.NonImpl <em>Non</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see contraintes.impl.NonImpl
		 * @see contraintes.impl.ContraintesPackageImpl#getNon()
		 * @generated
		 */
		EClass NON = eINSTANCE.getNon();

		/**
		 * The meta object literal for the '<em><b>Operande</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference NON__OPERANDE = eINSTANCE.getNon_Operande();

		/**
		 * The meta object literal for the '{@link contraintes.impl.MinDistanceImpl <em>Min Distance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see contraintes.impl.MinDistanceImpl
		 * @see contraintes.impl.ContraintesPackageImpl#getMinDistance()
		 * @generated
		 */
		EClass MIN_DISTANCE = eINSTANCE.getMinDistance();

		/**
		 * The meta object literal for the '<em><b>Min Distance</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MIN_DISTANCE__MIN_DISTANCE = eINSTANCE.getMinDistance_MinDistance();

		/**
		 * The meta object literal for the '<em><b>Metadonnee Cle</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MIN_DISTANCE__METADONNEE_CLE = eINSTANCE.getMinDistance_MetadonneeCle();

		/**
		 * The meta object literal for the '{@link contraintes.impl.ZoneInterditeImpl <em>Zone Interdite</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see contraintes.impl.ZoneInterditeImpl
		 * @see contraintes.impl.ContraintesPackageImpl#getZoneInterdite()
		 * @generated
		 */
		EClass ZONE_INTERDITE = eINSTANCE.getZoneInterdite();

		/**
		 * The meta object literal for the '<em><b>X</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ZONE_INTERDITE__X = eINSTANCE.getZoneInterdite_X();

		/**
		 * The meta object literal for the '<em><b>Y</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ZONE_INTERDITE__Y = eINSTANCE.getZoneInterdite_Y();

		/**
		 * The meta object literal for the '<em><b>Width</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ZONE_INTERDITE__WIDTH = eINSTANCE.getZoneInterdite_Width();

		/**
		 * The meta object literal for the '<em><b>Height</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ZONE_INTERDITE__HEIGHT = eINSTANCE.getZoneInterdite_Height();

		/**
		 * The meta object literal for the '{@link contraintes.impl.ContrainteRedondanteImpl <em>Contrainte Redondante</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see contraintes.impl.ContrainteRedondanteImpl
		 * @see contraintes.impl.ContraintesPackageImpl#getContrainteRedondante()
		 * @generated
		 */
		EClass CONTRAINTE_REDONDANTE = eINSTANCE.getContrainteRedondante();

		/**
		 * The meta object literal for the '<em><b>Count</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTRAINTE_REDONDANTE__COUNT = eINSTANCE.getContrainteRedondante_Count();

		/**
		 * The meta object literal for the '{@link contraintes.impl.ContrainteBoardsImpl <em>Contrainte Boards</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see contraintes.impl.ContrainteBoardsImpl
		 * @see contraintes.impl.ContraintesPackageImpl#getContrainteBoards()
		 * @generated
		 */
		EClass CONTRAINTE_BOARDS = eINSTANCE.getContrainteBoards();

		/**
		 * The meta object literal for the '<em><b>Couche Requise</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTRAINTE_BOARDS__COUCHE_REQUISE = eINSTANCE.getContrainteBoards_CoucheRequise();

		/**
		 * The meta object literal for the '<em><b>Couche Externe Interdite</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONTRAINTE_BOARDS__COUCHE_EXTERNE_INTERDITE = eINSTANCE.getContrainteBoards_CoucheExterneInterdite();

	}

} //ContraintesPackage
