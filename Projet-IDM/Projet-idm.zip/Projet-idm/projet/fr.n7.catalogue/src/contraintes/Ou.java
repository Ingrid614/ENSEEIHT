/**
 */
package contraintes;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ou</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link contraintes.Ou#getGauche <em>Gauche</em>}</li>
 *   <li>{@link contraintes.Ou#getDroite <em>Droite</em>}</li>
 * </ul>
 *
 * @see contraintes.ContraintesPackage#getOu()
 * @model
 * @generated
 */
public interface Ou extends Contrainte {
	/**
	 * Returns the value of the '<em><b>Gauche</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Gauche</em>' reference.
	 * @see #setGauche(Contrainte)
	 * @see contraintes.ContraintesPackage#getOu_Gauche()
	 * @model required="true"
	 * @generated
	 */
	Contrainte getGauche();

	/**
	 * Sets the value of the '{@link contraintes.Ou#getGauche <em>Gauche</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Gauche</em>' reference.
	 * @see #getGauche()
	 * @generated
	 */
	void setGauche(Contrainte value);

	/**
	 * Returns the value of the '<em><b>Droite</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Droite</em>' reference.
	 * @see #setDroite(Contrainte)
	 * @see contraintes.ContraintesPackage#getOu_Droite()
	 * @model required="true"
	 * @generated
	 */
	Contrainte getDroite();

	/**
	 * Sets the value of the '{@link contraintes.Ou#getDroite <em>Droite</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Droite</em>' reference.
	 * @see #getDroite()
	 * @generated
	 */
	void setDroite(Contrainte value);

} // Ou
