/**
 */
package contraintes;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Non</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link contraintes.Non#getOperande <em>Operande</em>}</li>
 * </ul>
 *
 * @see contraintes.ContraintesPackage#getNon()
 * @model
 * @generated
 */
public interface Non extends Contrainte {
	/**
	 * Returns the value of the '<em><b>Operande</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Operande</em>' reference.
	 * @see #setOperande(Contrainte)
	 * @see contraintes.ContraintesPackage#getNon_Operande()
	 * @model required="true"
	 * @generated
	 */
	Contrainte getOperande();

	/**
	 * Sets the value of the '{@link contraintes.Non#getOperande <em>Operande</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Operande</em>' reference.
	 * @see #getOperande()
	 * @generated
	 */
	void setOperande(Contrainte value);

} // Non
