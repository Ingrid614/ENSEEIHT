/**
 */
package contraintes.util;

import contraintes.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see contraintes.ContraintesPackage
 * @generated
 */
public class ContraintesSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static ContraintesPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContraintesSwitch() {
		if (modelPackage == null) {
			modelPackage = ContraintesPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
			case ContraintesPackage.CONTRAINTE: {
				Contrainte contrainte = (Contrainte)theEObject;
				T result = caseContrainte(contrainte);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case ContraintesPackage.ET: {
				ET et = (ET)theEObject;
				T result = caseET(et);
				if (result == null) result = caseContrainte(et);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case ContraintesPackage.OU: {
				Ou ou = (Ou)theEObject;
				T result = caseOu(ou);
				if (result == null) result = caseContrainte(ou);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case ContraintesPackage.NON: {
				Non non = (Non)theEObject;
				T result = caseNon(non);
				if (result == null) result = caseContrainte(non);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case ContraintesPackage.MIN_DISTANCE: {
				MinDistance minDistance = (MinDistance)theEObject;
				T result = caseMinDistance(minDistance);
				if (result == null) result = caseContrainte(minDistance);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case ContraintesPackage.ZONE_INTERDITE: {
				ZoneInterdite zoneInterdite = (ZoneInterdite)theEObject;
				T result = caseZoneInterdite(zoneInterdite);
				if (result == null) result = caseContrainte(zoneInterdite);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case ContraintesPackage.CONTRAINTE_REDONDANTE: {
				ContrainteRedondante contrainteRedondante = (ContrainteRedondante)theEObject;
				T result = caseContrainteRedondante(contrainteRedondante);
				if (result == null) result = caseContrainte(contrainteRedondante);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			case ContraintesPackage.CONTRAINTE_BOARDS: {
				ContrainteBoards contrainteBoards = (ContrainteBoards)theEObject;
				T result = caseContrainteBoards(contrainteBoards);
				if (result == null) result = caseContrainte(contrainteBoards);
				if (result == null) result = defaultCase(theEObject);
				return result;
			}
			default: return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Contrainte</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Contrainte</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseContrainte(Contrainte object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>ET</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>ET</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseET(ET object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Ou</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Ou</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOu(Ou object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Non</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Non</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNon(Non object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Min Distance</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Min Distance</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMinDistance(MinDistance object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Zone Interdite</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Zone Interdite</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseZoneInterdite(ZoneInterdite object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Contrainte Redondante</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Contrainte Redondante</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseContrainteRedondante(ContrainteRedondante object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Contrainte Boards</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Contrainte Boards</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseContrainteBoards(ContrainteBoards object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //ContraintesSwitch
