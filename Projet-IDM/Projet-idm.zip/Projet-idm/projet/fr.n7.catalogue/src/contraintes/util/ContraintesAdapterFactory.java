/**
 */
package contraintes.util;

import contraintes.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see contraintes.ContraintesPackage
 * @generated
 */
public class ContraintesAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static ContraintesPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ContraintesAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = ContraintesPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ContraintesSwitch<Adapter> modelSwitch =
		new ContraintesSwitch<Adapter>() {
			@Override
			public Adapter caseContrainte(Contrainte object) {
				return createContrainteAdapter();
			}
			@Override
			public Adapter caseET(ET object) {
				return createETAdapter();
			}
			@Override
			public Adapter caseOu(Ou object) {
				return createOuAdapter();
			}
			@Override
			public Adapter caseNon(Non object) {
				return createNonAdapter();
			}
			@Override
			public Adapter caseMinDistance(MinDistance object) {
				return createMinDistanceAdapter();
			}
			@Override
			public Adapter caseZoneInterdite(ZoneInterdite object) {
				return createZoneInterditeAdapter();
			}
			@Override
			public Adapter caseContrainteRedondante(ContrainteRedondante object) {
				return createContrainteRedondanteAdapter();
			}
			@Override
			public Adapter caseContrainteBoards(ContrainteBoards object) {
				return createContrainteBoardsAdapter();
			}
			@Override
			public Adapter defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link contraintes.Contrainte <em>Contrainte</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see contraintes.Contrainte
	 * @generated
	 */
	public Adapter createContrainteAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link contraintes.ET <em>ET</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see contraintes.ET
	 * @generated
	 */
	public Adapter createETAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link contraintes.Ou <em>Ou</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see contraintes.Ou
	 * @generated
	 */
	public Adapter createOuAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link contraintes.Non <em>Non</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see contraintes.Non
	 * @generated
	 */
	public Adapter createNonAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link contraintes.MinDistance <em>Min Distance</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see contraintes.MinDistance
	 * @generated
	 */
	public Adapter createMinDistanceAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link contraintes.ZoneInterdite <em>Zone Interdite</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see contraintes.ZoneInterdite
	 * @generated
	 */
	public Adapter createZoneInterditeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link contraintes.ContrainteRedondante <em>Contrainte Redondante</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see contraintes.ContrainteRedondante
	 * @generated
	 */
	public Adapter createContrainteRedondanteAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link contraintes.ContrainteBoards <em>Contrainte Boards</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see contraintes.ContrainteBoards
	 * @generated
	 */
	public Adapter createContrainteBoardsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //ContraintesAdapterFactory
