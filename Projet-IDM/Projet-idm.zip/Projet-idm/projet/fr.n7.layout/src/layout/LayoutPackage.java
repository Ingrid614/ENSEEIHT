/**
 */
package layout;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see layout.LayoutFactory
 * @model kind="package"
 * @generated
 */
public interface LayoutPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "layout";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/layout";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "layout";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	LayoutPackage eINSTANCE = layout.impl.LayoutPackageImpl.init();

	/**
	 * The meta object id for the '{@link layout.impl.LayoutImpl <em>Layout</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see layout.impl.LayoutImpl
	 * @see layout.impl.LayoutPackageImpl#getLayout()
	 * @generated
	 */
	int LAYOUT = 0;

	/**
	 * The feature id for the '<em><b>Netlist</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYOUT__NETLIST = 0;

	/**
	 * The feature id for the '<em><b>Boards</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYOUT__BOARDS = 1;

	/**
	 * The number of structural features of the '<em>Layout</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYOUT_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Layout</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYOUT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link layout.impl.BoardImpl <em>Board</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see layout.impl.BoardImpl
	 * @see layout.impl.LayoutPackageImpl#getBoard()
	 * @generated
	 */
	int BOARD = 1;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BOARD__ID = 0;

	/**
	 * The feature id for the '<em><b>Couches</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BOARD__COUCHES = 1;

	/**
	 * The number of structural features of the '<em>Board</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BOARD_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Board</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BOARD_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link layout.impl.CoucheImpl <em>Couche</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see layout.impl.CoucheImpl
	 * @see layout.impl.LayoutPackageImpl#getCouche()
	 * @generated
	 */
	int COUCHE = 2;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUCHE__ID = 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUCHE__TYPE = 1;

	/**
	 * The feature id for the '<em><b>Placements</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUCHE__PLACEMENTS = 2;

	/**
	 * The feature id for the '<em><b>Pistes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUCHE__PISTES = 3;

	/**
	 * The number of structural features of the '<em>Couche</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUCHE_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Couche</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COUCHE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link layout.impl.PlacementComposantImpl <em>Placement Composant</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see layout.impl.PlacementComposantImpl
	 * @see layout.impl.LayoutPackageImpl#getPlacementComposant()
	 * @generated
	 */
	int PLACEMENT_COMPOSANT = 3;

	/**
	 * The feature id for the '<em><b>Instance</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLACEMENT_COMPOSANT__INSTANCE = 0;

	/**
	 * The feature id for the '<em><b>Side</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLACEMENT_COMPOSANT__SIDE = 1;

	/**
	 * The feature id for the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLACEMENT_COMPOSANT__X = 2;

	/**
	 * The feature id for the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLACEMENT_COMPOSANT__Y = 3;

	/**
	 * The number of structural features of the '<em>Placement Composant</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLACEMENT_COMPOSANT_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Placement Composant</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PLACEMENT_COMPOSANT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link layout.impl.PisteImpl <em>Piste</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see layout.impl.PisteImpl
	 * @see layout.impl.LayoutPackageImpl#getPiste()
	 * @generated
	 */
	int PISTE = 4;

	/**
	 * The feature id for the '<em><b>Net</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PISTE__NET = 0;

	/**
	 * The feature id for the '<em><b>Points</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PISTE__POINTS = 1;

	/**
	 * The number of structural features of the '<em>Piste</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PISTE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Piste</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PISTE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link layout.impl.PointPisteImpl <em>Point Piste</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see layout.impl.PointPisteImpl
	 * @see layout.impl.LayoutPackageImpl#getPointPiste()
	 * @generated
	 */
	int POINT_PISTE = 5;

	/**
	 * The feature id for the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POINT_PISTE__X = 0;

	/**
	 * The feature id for the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POINT_PISTE__Y = 1;

	/**
	 * The number of structural features of the '<em>Point Piste</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POINT_PISTE_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Point Piste</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POINT_PISTE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link layout.TypeCouche <em>Type Couche</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see layout.TypeCouche
	 * @see layout.impl.LayoutPackageImpl#getTypeCouche()
	 * @generated
	 */
	int TYPE_COUCHE = 6;

	/**
	 * The meta object id for the '{@link layout.Sides <em>Sides</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see layout.Sides
	 * @see layout.impl.LayoutPackageImpl#getSides()
	 * @generated
	 */
	int SIDES = 7;


	/**
	 * Returns the meta object for class '{@link layout.Layout <em>Layout</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Layout</em>'.
	 * @see layout.Layout
	 * @generated
	 */
	EClass getLayout();

	/**
	 * Returns the meta object for the reference '{@link layout.Layout#getNetlist <em>Netlist</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Netlist</em>'.
	 * @see layout.Layout#getNetlist()
	 * @see #getLayout()
	 * @generated
	 */
	EReference getLayout_Netlist();

	/**
	 * Returns the meta object for the reference list '{@link layout.Layout#getBoards <em>Boards</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Boards</em>'.
	 * @see layout.Layout#getBoards()
	 * @see #getLayout()
	 * @generated
	 */
	EReference getLayout_Boards();

	/**
	 * Returns the meta object for class '{@link layout.Board <em>Board</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Board</em>'.
	 * @see layout.Board
	 * @generated
	 */
	EClass getBoard();

	/**
	 * Returns the meta object for the attribute '{@link layout.Board#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see layout.Board#getId()
	 * @see #getBoard()
	 * @generated
	 */
	EAttribute getBoard_Id();

	/**
	 * Returns the meta object for the reference list '{@link layout.Board#getCouches <em>Couches</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Couches</em>'.
	 * @see layout.Board#getCouches()
	 * @see #getBoard()
	 * @generated
	 */
	EReference getBoard_Couches();

	/**
	 * Returns the meta object for class '{@link layout.Couche <em>Couche</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Couche</em>'.
	 * @see layout.Couche
	 * @generated
	 */
	EClass getCouche();

	/**
	 * Returns the meta object for the attribute '{@link layout.Couche#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see layout.Couche#getId()
	 * @see #getCouche()
	 * @generated
	 */
	EAttribute getCouche_Id();

	/**
	 * Returns the meta object for the attribute '{@link layout.Couche#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see layout.Couche#getType()
	 * @see #getCouche()
	 * @generated
	 */
	EAttribute getCouche_Type();

	/**
	 * Returns the meta object for the reference list '{@link layout.Couche#getPlacements <em>Placements</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Placements</em>'.
	 * @see layout.Couche#getPlacements()
	 * @see #getCouche()
	 * @generated
	 */
	EReference getCouche_Placements();

	/**
	 * Returns the meta object for the reference list '{@link layout.Couche#getPistes <em>Pistes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Pistes</em>'.
	 * @see layout.Couche#getPistes()
	 * @see #getCouche()
	 * @generated
	 */
	EReference getCouche_Pistes();

	/**
	 * Returns the meta object for class '{@link layout.PlacementComposant <em>Placement Composant</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Placement Composant</em>'.
	 * @see layout.PlacementComposant
	 * @generated
	 */
	EClass getPlacementComposant();

	/**
	 * Returns the meta object for the reference '{@link layout.PlacementComposant#getInstance <em>Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Instance</em>'.
	 * @see layout.PlacementComposant#getInstance()
	 * @see #getPlacementComposant()
	 * @generated
	 */
	EReference getPlacementComposant_Instance();

	/**
	 * Returns the meta object for the attribute '{@link layout.PlacementComposant#getSide <em>Side</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Side</em>'.
	 * @see layout.PlacementComposant#getSide()
	 * @see #getPlacementComposant()
	 * @generated
	 */
	EAttribute getPlacementComposant_Side();

	/**
	 * Returns the meta object for the attribute '{@link layout.PlacementComposant#getX <em>X</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>X</em>'.
	 * @see layout.PlacementComposant#getX()
	 * @see #getPlacementComposant()
	 * @generated
	 */
	EAttribute getPlacementComposant_X();

	/**
	 * Returns the meta object for the attribute '{@link layout.PlacementComposant#getY <em>Y</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Y</em>'.
	 * @see layout.PlacementComposant#getY()
	 * @see #getPlacementComposant()
	 * @generated
	 */
	EAttribute getPlacementComposant_Y();

	/**
	 * Returns the meta object for class '{@link layout.Piste <em>Piste</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Piste</em>'.
	 * @see layout.Piste
	 * @generated
	 */
	EClass getPiste();

	/**
	 * Returns the meta object for the reference '{@link layout.Piste#getNet <em>Net</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Net</em>'.
	 * @see layout.Piste#getNet()
	 * @see #getPiste()
	 * @generated
	 */
	EReference getPiste_Net();

	/**
	 * Returns the meta object for the reference list '{@link layout.Piste#getPoints <em>Points</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Points</em>'.
	 * @see layout.Piste#getPoints()
	 * @see #getPiste()
	 * @generated
	 */
	EReference getPiste_Points();

	/**
	 * Returns the meta object for class '{@link layout.PointPiste <em>Point Piste</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Point Piste</em>'.
	 * @see layout.PointPiste
	 * @generated
	 */
	EClass getPointPiste();

	/**
	 * Returns the meta object for the attribute '{@link layout.PointPiste#getX <em>X</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>X</em>'.
	 * @see layout.PointPiste#getX()
	 * @see #getPointPiste()
	 * @generated
	 */
	EAttribute getPointPiste_X();

	/**
	 * Returns the meta object for the attribute '{@link layout.PointPiste#getY <em>Y</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Y</em>'.
	 * @see layout.PointPiste#getY()
	 * @see #getPointPiste()
	 * @generated
	 */
	EAttribute getPointPiste_Y();

	/**
	 * Returns the meta object for enum '{@link layout.TypeCouche <em>Type Couche</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Type Couche</em>'.
	 * @see layout.TypeCouche
	 * @generated
	 */
	EEnum getTypeCouche();

	/**
	 * Returns the meta object for enum '{@link layout.Sides <em>Sides</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Sides</em>'.
	 * @see layout.Sides
	 * @generated
	 */
	EEnum getSides();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	LayoutFactory getLayoutFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link layout.impl.LayoutImpl <em>Layout</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see layout.impl.LayoutImpl
		 * @see layout.impl.LayoutPackageImpl#getLayout()
		 * @generated
		 */
		EClass LAYOUT = eINSTANCE.getLayout();

		/**
		 * The meta object literal for the '<em><b>Netlist</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LAYOUT__NETLIST = eINSTANCE.getLayout_Netlist();

		/**
		 * The meta object literal for the '<em><b>Boards</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LAYOUT__BOARDS = eINSTANCE.getLayout_Boards();

		/**
		 * The meta object literal for the '{@link layout.impl.BoardImpl <em>Board</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see layout.impl.BoardImpl
		 * @see layout.impl.LayoutPackageImpl#getBoard()
		 * @generated
		 */
		EClass BOARD = eINSTANCE.getBoard();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BOARD__ID = eINSTANCE.getBoard_Id();

		/**
		 * The meta object literal for the '<em><b>Couches</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BOARD__COUCHES = eINSTANCE.getBoard_Couches();

		/**
		 * The meta object literal for the '{@link layout.impl.CoucheImpl <em>Couche</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see layout.impl.CoucheImpl
		 * @see layout.impl.LayoutPackageImpl#getCouche()
		 * @generated
		 */
		EClass COUCHE = eINSTANCE.getCouche();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COUCHE__ID = eINSTANCE.getCouche_Id();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COUCHE__TYPE = eINSTANCE.getCouche_Type();

		/**
		 * The meta object literal for the '<em><b>Placements</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COUCHE__PLACEMENTS = eINSTANCE.getCouche_Placements();

		/**
		 * The meta object literal for the '<em><b>Pistes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COUCHE__PISTES = eINSTANCE.getCouche_Pistes();

		/**
		 * The meta object literal for the '{@link layout.impl.PlacementComposantImpl <em>Placement Composant</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see layout.impl.PlacementComposantImpl
		 * @see layout.impl.LayoutPackageImpl#getPlacementComposant()
		 * @generated
		 */
		EClass PLACEMENT_COMPOSANT = eINSTANCE.getPlacementComposant();

		/**
		 * The meta object literal for the '<em><b>Instance</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PLACEMENT_COMPOSANT__INSTANCE = eINSTANCE.getPlacementComposant_Instance();

		/**
		 * The meta object literal for the '<em><b>Side</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PLACEMENT_COMPOSANT__SIDE = eINSTANCE.getPlacementComposant_Side();

		/**
		 * The meta object literal for the '<em><b>X</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PLACEMENT_COMPOSANT__X = eINSTANCE.getPlacementComposant_X();

		/**
		 * The meta object literal for the '<em><b>Y</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PLACEMENT_COMPOSANT__Y = eINSTANCE.getPlacementComposant_Y();

		/**
		 * The meta object literal for the '{@link layout.impl.PisteImpl <em>Piste</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see layout.impl.PisteImpl
		 * @see layout.impl.LayoutPackageImpl#getPiste()
		 * @generated
		 */
		EClass PISTE = eINSTANCE.getPiste();

		/**
		 * The meta object literal for the '<em><b>Net</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PISTE__NET = eINSTANCE.getPiste_Net();

		/**
		 * The meta object literal for the '<em><b>Points</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PISTE__POINTS = eINSTANCE.getPiste_Points();

		/**
		 * The meta object literal for the '{@link layout.impl.PointPisteImpl <em>Point Piste</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see layout.impl.PointPisteImpl
		 * @see layout.impl.LayoutPackageImpl#getPointPiste()
		 * @generated
		 */
		EClass POINT_PISTE = eINSTANCE.getPointPiste();

		/**
		 * The meta object literal for the '<em><b>X</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POINT_PISTE__X = eINSTANCE.getPointPiste_X();

		/**
		 * The meta object literal for the '<em><b>Y</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POINT_PISTE__Y = eINSTANCE.getPointPiste_Y();

		/**
		 * The meta object literal for the '{@link layout.TypeCouche <em>Type Couche</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see layout.TypeCouche
		 * @see layout.impl.LayoutPackageImpl#getTypeCouche()
		 * @generated
		 */
		EEnum TYPE_COUCHE = eINSTANCE.getTypeCouche();

		/**
		 * The meta object literal for the '{@link layout.Sides <em>Sides</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see layout.Sides
		 * @see layout.impl.LayoutPackageImpl#getSides()
		 * @generated
		 */
		EEnum SIDES = eINSTANCE.getSides();

	}

} //LayoutPackage
