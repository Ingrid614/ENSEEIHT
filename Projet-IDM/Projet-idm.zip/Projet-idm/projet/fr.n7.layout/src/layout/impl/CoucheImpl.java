/**
 */
package layout.impl;

import java.util.Collection;

import layout.Couche;
import layout.LayoutPackage;
import layout.Piste;
import layout.PlacementComposant;
import layout.TypeCouche;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Couche</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link layout.impl.CoucheImpl#getId <em>Id</em>}</li>
 *   <li>{@link layout.impl.CoucheImpl#getType <em>Type</em>}</li>
 *   <li>{@link layout.impl.CoucheImpl#getPlacements <em>Placements</em>}</li>
 *   <li>{@link layout.impl.CoucheImpl#getPistes <em>Pistes</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CoucheImpl extends MinimalEObjectImpl.Container implements Couche {
	/**
	 * The default value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected String id = ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final TypeCouche TYPE_EDEFAULT = TypeCouche.EXTERNE;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected TypeCouche type = TYPE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPlacements() <em>Placements</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlacements()
	 * @generated
	 * @ordered
	 */
	protected EList<PlacementComposant> placements;

	/**
	 * The cached value of the '{@link #getPistes() <em>Pistes</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPistes()
	 * @generated
	 * @ordered
	 */
	protected EList<Piste> pistes;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CoucheImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LayoutPackage.Literals.COUCHE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getId() {
		return id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setId(String newId) {
		String oldId = id;
		id = newId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LayoutPackage.COUCHE__ID, oldId, id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TypeCouche getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setType(TypeCouche newType) {
		TypeCouche oldType = type;
		type = newType == null ? TYPE_EDEFAULT : newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LayoutPackage.COUCHE__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<PlacementComposant> getPlacements() {
		if (placements == null) {
			placements = new EObjectResolvingEList<PlacementComposant>(PlacementComposant.class, this, LayoutPackage.COUCHE__PLACEMENTS);
		}
		return placements;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Piste> getPistes() {
		if (pistes == null) {
			pistes = new EObjectResolvingEList<Piste>(Piste.class, this, LayoutPackage.COUCHE__PISTES);
		}
		return pistes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case LayoutPackage.COUCHE__ID:
				return getId();
			case LayoutPackage.COUCHE__TYPE:
				return getType();
			case LayoutPackage.COUCHE__PLACEMENTS:
				return getPlacements();
			case LayoutPackage.COUCHE__PISTES:
				return getPistes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case LayoutPackage.COUCHE__ID:
				setId((String)newValue);
				return;
			case LayoutPackage.COUCHE__TYPE:
				setType((TypeCouche)newValue);
				return;
			case LayoutPackage.COUCHE__PLACEMENTS:
				getPlacements().clear();
				getPlacements().addAll((Collection<? extends PlacementComposant>)newValue);
				return;
			case LayoutPackage.COUCHE__PISTES:
				getPistes().clear();
				getPistes().addAll((Collection<? extends Piste>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case LayoutPackage.COUCHE__ID:
				setId(ID_EDEFAULT);
				return;
			case LayoutPackage.COUCHE__TYPE:
				setType(TYPE_EDEFAULT);
				return;
			case LayoutPackage.COUCHE__PLACEMENTS:
				getPlacements().clear();
				return;
			case LayoutPackage.COUCHE__PISTES:
				getPistes().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case LayoutPackage.COUCHE__ID:
				return ID_EDEFAULT == null ? id != null : !ID_EDEFAULT.equals(id);
			case LayoutPackage.COUCHE__TYPE:
				return type != TYPE_EDEFAULT;
			case LayoutPackage.COUCHE__PLACEMENTS:
				return placements != null && !placements.isEmpty();
			case LayoutPackage.COUCHE__PISTES:
				return pistes != null && !pistes.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (id: ");
		result.append(id);
		result.append(", type: ");
		result.append(type);
		result.append(')');
		return result.toString();
	}

} //CoucheImpl
