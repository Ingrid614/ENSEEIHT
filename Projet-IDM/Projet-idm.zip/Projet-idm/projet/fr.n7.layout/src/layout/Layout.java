/**
 */
package layout;

import netlist.Netlist;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Layout</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link layout.Layout#getNetlist <em>Netlist</em>}</li>
 *   <li>{@link layout.Layout#getBoards <em>Boards</em>}</li>
 * </ul>
 *
 * @see layout.LayoutPackage#getLayout()
 * @model
 * @generated
 */
public interface Layout extends EObject {
	/**
	 * Returns the value of the '<em><b>Netlist</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Netlist</em>' reference.
	 * @see #setNetlist(Netlist)
	 * @see layout.LayoutPackage#getLayout_Netlist()
	 * @model required="true"
	 * @generated
	 */
	Netlist getNetlist();

	/**
	 * Sets the value of the '{@link layout.Layout#getNetlist <em>Netlist</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Netlist</em>' reference.
	 * @see #getNetlist()
	 * @generated
	 */
	void setNetlist(Netlist value);

	/**
	 * Returns the value of the '<em><b>Boards</b></em>' reference list.
	 * The list contents are of type {@link layout.Board}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Boards</em>' reference list.
	 * @see layout.LayoutPackage#getLayout_Boards()
	 * @model
	 * @generated
	 */
	EList<Board> getBoards();

} // Layout
