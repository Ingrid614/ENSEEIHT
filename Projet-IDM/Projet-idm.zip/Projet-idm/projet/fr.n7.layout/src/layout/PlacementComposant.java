/**
 */
package layout;

import netlist.ComposantInstance;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Placement Composant</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link layout.PlacementComposant#getInstance <em>Instance</em>}</li>
 *   <li>{@link layout.PlacementComposant#getSide <em>Side</em>}</li>
 *   <li>{@link layout.PlacementComposant#getX <em>X</em>}</li>
 *   <li>{@link layout.PlacementComposant#getY <em>Y</em>}</li>
 * </ul>
 *
 * @see layout.LayoutPackage#getPlacementComposant()
 * @model
 * @generated
 */
public interface PlacementComposant extends EObject {
	/**
	 * Returns the value of the '<em><b>Instance</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Instance</em>' reference.
	 * @see #setInstance(ComposantInstance)
	 * @see layout.LayoutPackage#getPlacementComposant_Instance()
	 * @model
	 * @generated
	 */
	ComposantInstance getInstance();

	/**
	 * Sets the value of the '{@link layout.PlacementComposant#getInstance <em>Instance</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Instance</em>' reference.
	 * @see #getInstance()
	 * @generated
	 */
	void setInstance(ComposantInstance value);

	/**
	 * Returns the value of the '<em><b>Side</b></em>' attribute.
	 * The literals are from the enumeration {@link layout.Sides}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Side</em>' attribute.
	 * @see layout.Sides
	 * @see #setSide(Sides)
	 * @see layout.LayoutPackage#getPlacementComposant_Side()
	 * @model
	 * @generated
	 */
	Sides getSide();

	/**
	 * Sets the value of the '{@link layout.PlacementComposant#getSide <em>Side</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Side</em>' attribute.
	 * @see layout.Sides
	 * @see #getSide()
	 * @generated
	 */
	void setSide(Sides value);

	/**
	 * Returns the value of the '<em><b>X</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>X</em>' attribute.
	 * @see #setX(double)
	 * @see layout.LayoutPackage#getPlacementComposant_X()
	 * @model
	 * @generated
	 */
	double getX();

	/**
	 * Sets the value of the '{@link layout.PlacementComposant#getX <em>X</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>X</em>' attribute.
	 * @see #getX()
	 * @generated
	 */
	void setX(double value);

	/**
	 * Returns the value of the '<em><b>Y</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Y</em>' attribute.
	 * @see #setY(double)
	 * @see layout.LayoutPackage#getPlacementComposant_Y()
	 * @model
	 * @generated
	 */
	double getY();

	/**
	 * Sets the value of the '{@link layout.PlacementComposant#getY <em>Y</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Y</em>' attribute.
	 * @see #getY()
	 * @generated
	 */
	void setY(double value);

} // PlacementComposant
