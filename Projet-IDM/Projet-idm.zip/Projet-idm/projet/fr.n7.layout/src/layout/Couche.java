/**
 */
package layout;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Couche</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link layout.Couche#getId <em>Id</em>}</li>
 *   <li>{@link layout.Couche#getType <em>Type</em>}</li>
 *   <li>{@link layout.Couche#getPlacements <em>Placements</em>}</li>
 *   <li>{@link layout.Couche#getPistes <em>Pistes</em>}</li>
 * </ul>
 *
 * @see layout.LayoutPackage#getCouche()
 * @model
 * @generated
 */
public interface Couche extends EObject {
	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #setId(String)
	 * @see layout.LayoutPackage#getCouche_Id()
	 * @model
	 * @generated
	 */
	String getId();

	/**
	 * Sets the value of the '{@link layout.Couche#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id</em>' attribute.
	 * @see #getId()
	 * @generated
	 */
	void setId(String value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link layout.TypeCouche}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see layout.TypeCouche
	 * @see #setType(TypeCouche)
	 * @see layout.LayoutPackage#getCouche_Type()
	 * @model
	 * @generated
	 */
	TypeCouche getType();

	/**
	 * Sets the value of the '{@link layout.Couche#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see layout.TypeCouche
	 * @see #getType()
	 * @generated
	 */
	void setType(TypeCouche value);

	/**
	 * Returns the value of the '<em><b>Placements</b></em>' reference list.
	 * The list contents are of type {@link layout.PlacementComposant}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Placements</em>' reference list.
	 * @see layout.LayoutPackage#getCouche_Placements()
	 * @model
	 * @generated
	 */
	EList<PlacementComposant> getPlacements();

	/**
	 * Returns the value of the '<em><b>Pistes</b></em>' reference list.
	 * The list contents are of type {@link layout.Piste}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pistes</em>' reference list.
	 * @see layout.LayoutPackage#getCouche_Pistes()
	 * @model
	 * @generated
	 */
	EList<Piste> getPistes();

} // Couche
