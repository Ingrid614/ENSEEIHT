/**
 */
package contraintes.impl;

import contraintes.Contrainte;
import contraintes.ContrainteBoards;
import contraintes.ContrainteRedondante;
import contraintes.ContraintesFactory;
import contraintes.ContraintesPackage;
import contraintes.MinDistance;
import contraintes.Non;
import contraintes.Ou;
import contraintes.ZoneInterdite;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ContraintesPackageImpl extends EPackageImpl implements ContraintesPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass contrainteEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass etEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass ouEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass nonEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass minDistanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass zoneInterditeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass contrainteRedondanteEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass contrainteBoardsEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see contraintes.ContraintesPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private ContraintesPackageImpl() {
		super(eNS_URI, ContraintesFactory.eINSTANCE);
	}
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link ContraintesPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static ContraintesPackage init() {
		if (isInited) return (ContraintesPackage)EPackage.Registry.INSTANCE.getEPackage(ContraintesPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredContraintesPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		ContraintesPackageImpl theContraintesPackage = registeredContraintesPackage instanceof ContraintesPackageImpl ? (ContraintesPackageImpl)registeredContraintesPackage : new ContraintesPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theContraintesPackage.createPackageContents();

		// Initialize created meta-data
		theContraintesPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theContraintesPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(ContraintesPackage.eNS_URI, theContraintesPackage);
		return theContraintesPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getContrainte() {
		return contrainteEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getET() {
		return etEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getET_Gauche() {
		return (EReference)etEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getET_Droite() {
		return (EReference)etEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getOu() {
		return ouEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getOu_Gauche() {
		return (EReference)ouEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getOu_Droite() {
		return (EReference)ouEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getNon() {
		return nonEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getNon_Operande() {
		return (EReference)nonEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMinDistance() {
		return minDistanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getMinDistance_MinDistance() {
		return (EAttribute)minDistanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getMinDistance_MetadonneeCle() {
		return (EAttribute)minDistanceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getZoneInterdite() {
		return zoneInterditeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getZoneInterdite_X() {
		return (EAttribute)zoneInterditeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getZoneInterdite_Y() {
		return (EAttribute)zoneInterditeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getZoneInterdite_Width() {
		return (EAttribute)zoneInterditeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getZoneInterdite_Height() {
		return (EAttribute)zoneInterditeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getContrainteRedondante() {
		return contrainteRedondanteEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getContrainteRedondante_Count() {
		return (EAttribute)contrainteRedondanteEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getContrainteBoards() {
		return contrainteBoardsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getContrainteBoards_CoucheRequise() {
		return (EAttribute)contrainteBoardsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getContrainteBoards_CoucheExterneInterdite() {
		return (EAttribute)contrainteBoardsEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ContraintesFactory getContraintesFactory() {
		return (ContraintesFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		contrainteEClass = createEClass(CONTRAINTE);

		etEClass = createEClass(ET);
		createEReference(etEClass, ET__GAUCHE);
		createEReference(etEClass, ET__DROITE);

		ouEClass = createEClass(OU);
		createEReference(ouEClass, OU__GAUCHE);
		createEReference(ouEClass, OU__DROITE);

		nonEClass = createEClass(NON);
		createEReference(nonEClass, NON__OPERANDE);

		minDistanceEClass = createEClass(MIN_DISTANCE);
		createEAttribute(minDistanceEClass, MIN_DISTANCE__MIN_DISTANCE);
		createEAttribute(minDistanceEClass, MIN_DISTANCE__METADONNEE_CLE);

		zoneInterditeEClass = createEClass(ZONE_INTERDITE);
		createEAttribute(zoneInterditeEClass, ZONE_INTERDITE__X);
		createEAttribute(zoneInterditeEClass, ZONE_INTERDITE__Y);
		createEAttribute(zoneInterditeEClass, ZONE_INTERDITE__WIDTH);
		createEAttribute(zoneInterditeEClass, ZONE_INTERDITE__HEIGHT);

		contrainteRedondanteEClass = createEClass(CONTRAINTE_REDONDANTE);
		createEAttribute(contrainteRedondanteEClass, CONTRAINTE_REDONDANTE__COUNT);

		contrainteBoardsEClass = createEClass(CONTRAINTE_BOARDS);
		createEAttribute(contrainteBoardsEClass, CONTRAINTE_BOARDS__COUCHE_REQUISE);
		createEAttribute(contrainteBoardsEClass, CONTRAINTE_BOARDS__COUCHE_EXTERNE_INTERDITE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		etEClass.getESuperTypes().add(this.getContrainte());
		ouEClass.getESuperTypes().add(this.getContrainte());
		nonEClass.getESuperTypes().add(this.getContrainte());
		minDistanceEClass.getESuperTypes().add(this.getContrainte());
		zoneInterditeEClass.getESuperTypes().add(this.getContrainte());
		contrainteRedondanteEClass.getESuperTypes().add(this.getContrainte());
		contrainteBoardsEClass.getESuperTypes().add(this.getContrainte());

		// Initialize classes, features, and operations; add parameters
		initEClass(contrainteEClass, Contrainte.class, "Contrainte", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(etEClass, contraintes.ET.class, "ET", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getET_Gauche(), this.getContrainte(), null, "gauche", null, 1, 1, contraintes.ET.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getET_Droite(), this.getContrainte(), null, "droite", null, 1, 1, contraintes.ET.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(ouEClass, Ou.class, "Ou", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getOu_Gauche(), this.getContrainte(), null, "gauche", null, 1, 1, Ou.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getOu_Droite(), this.getContrainte(), null, "droite", null, 1, 1, Ou.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(nonEClass, Non.class, "Non", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getNon_Operande(), this.getContrainte(), null, "operande", null, 1, 1, Non.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(minDistanceEClass, MinDistance.class, "MinDistance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMinDistance_MinDistance(), ecorePackage.getEString(), "minDistance", null, 1, 1, MinDistance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMinDistance_MetadonneeCle(), ecorePackage.getEString(), "metadonneeCle", null, 1, 1, MinDistance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(zoneInterditeEClass, ZoneInterdite.class, "ZoneInterdite", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getZoneInterdite_X(), ecorePackage.getEDouble(), "x", null, 1, 1, ZoneInterdite.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getZoneInterdite_Y(), ecorePackage.getEDouble(), "y", null, 1, 1, ZoneInterdite.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getZoneInterdite_Width(), ecorePackage.getEDouble(), "width", null, 1, 1, ZoneInterdite.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getZoneInterdite_Height(), ecorePackage.getEDouble(), "height", null, 1, 1, ZoneInterdite.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(contrainteRedondanteEClass, ContrainteRedondante.class, "ContrainteRedondante", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getContrainteRedondante_Count(), ecorePackage.getEInt(), "count", null, 1, 1, ContrainteRedondante.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(contrainteBoardsEClass, ContrainteBoards.class, "ContrainteBoards", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getContrainteBoards_CoucheRequise(), ecorePackage.getEString(), "coucheRequise", null, 1, 1, ContrainteBoards.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getContrainteBoards_CoucheExterneInterdite(), ecorePackage.getEBoolean(), "coucheExterneInterdite", null, 1, 1, ContrainteBoards.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //ContraintesPackageImpl
